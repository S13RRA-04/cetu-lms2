# PACT Rebuild — Packet 1 Manifest: "The Victims"
**Drop day:** Monday AM (Day 1) · **Status:** DESIGN — pending Cody approval before content generation
**Classification note:** No banners on any Packet 1 file. All files are victim-native. Banners appear only on FBI/instructor work products.

---

## 1. Packet-wide rules

1. **Inference ceiling (Packet 1):** Every file contains only what the victim's own systems, staff, or records produced. No RestonIT significance framing, no cross-victim references, no lifecycle/dormancy/IAB language, no attribution. RestonIT may appear **only** as an ordinary line item in vendor/AP records — never annotated, never highlighted.
2. **Distinct incident types:** CyberDyne = data theft · PixelPlay = ransomware · Dogwood = BEC · Redstone Memorial = detected intrusion/compromise. No file may describe another victim's incident.
3. **SaturnV Mart seeding rule:** SaturnV Mart appears **nowhere** in Packet 1. First appearance: one unremarkable client folder in the RestonIT records seized Wednesday (KCR). The live-access evidence discovered on scene triggers the Wednesday PM emergency-notification inject.
4. **All-digital rule:** Every artifact is a digital file (CSV, TXT, EML, PDF, JSON, HTML, LOG) plausibly resident on a device or produced by a records custodian. Nothing requires physical staging.
5. **IP discipline:** 192.0.2.0/24, 198.51.100.0/24, 203.0.113.0/24 only. IP assignments are centralized in §5 so no two files contradict.
6. **Tokens:** `PACT{PLACEHOLDER-xx}` only. Cody mints all real tokens.
7. **Tier tags (instructor manifest only, never in student files):** MF = Must-Find · CO = Corroborating · DE = Decoy · BE = Benign.
8. **Hook column:** Every hook names the legal instrument it predicates and the Packet 2 / Packet 3-AM return that answers it. A hook with no return, or a return with no hook, is a build error.

---

## 2. Canonical timeline — APPROVED (Sept 21–25, 2026 cohort)

All prior dates/IPs from the old build are retired. Approved spine:

| Phase | Window | Notes |
|---|---|---|
| RestonIT support engagements (provisioning) | May 2025 – Jan 2026 | Dormant accounts created during legitimate work at each client |
| Dormancy | Jan – Mar 2026 | No activity — the silence is the tell (visible only in later packets) |
| Black Harbor listings / sales (BRKR_AL → BRKR_RU) | Mar–Apr 2026 | Packet 3 material |
| Downstream intrusions (four victims) | May–Jul 2026 | Staggered; see per-victim dates below |
| Victim detection & complaints | Jun–Aug 2026 | Intake docs below |
| Course "present day" | Sep 21, 2026 | Investigation opens Monday |
| SaturnV Mart access (live) | Active during course week | Discovered on seized devices Wednesday |

Per-victim incident dates (locked): Dogwood mailbox rule created May 9, fraudulent wires May 26 & Jun 2 · CyberDyne exfil Jun 15–18, client report Jun 20, complaint Jun 23 · PixelPlay encryption Jul 11 · Redstone Memorial vishing call ~Jul 8, detection event Jul 30.

**Loss figures (locked):** CyberDyne ~$400K claimed exposure (~350 GB hosted client data) · Dogwood $48,200 + $61,750 wires, $37,400 recovered via recall of wire 2 · PixelPlay 0.4 BTC demand, ~$8K revenue impact, not paid · RMH $0 PHI loss, ~$15K containment cost. Gradient is deliberate: highest dollar (CDN) ≠ highest sensitivity (RMH) ≠ most process-rich (DGW) — Monday triage must be arguable.

---

## 3. Victim folders — file-by-file spec

Manifest IDs are instructor-side. Student-facing filenames are device-native (victims don't name files like evidence).

### 3.1 CyberDyne Data Center — DATA THEFT (folder: `cyberdyne/`)

| ID | Filename | Fmt | Tier | Summary | Hook → Return |
|---|---|---|---|---|---|
| P1-CDN-01 | `IC3_complaint_cyberdyne.pdf` | PDF (Email/slate NOT used — plain intake form style) | MF | Complaint intake: suspected theft of hosted client data, discovered Jun 20 after client Meridian Claims reported their data offered for sale on a breach forum; filed Jun 23 | Establishes federal nexus; victim production request → P2 account-creation records |
| P1-CDN-02 | `fw_egress_report_jun2026.csv` | CSV | MF | Firewall egress log excerpt Jun 14–19: ~350 GB outbound over 4 nights to 198.51.100.23, sourced from internal host 10.14.8.77 | ISP subpoena on 198.51.100.23 → P2 ISP return (resolves to foreign-hosted VPS — Wednesday AM priming return) |
| P1-CDN-03 | `asset_inventory_export.xlsx→csv` | CSV | MF | Official asset inventory. **10.14.8.77 is absent.** No explanation anywhere in Packet 1 | Supplemental production to CyberDyne re: unidentified host → P3-AM appliance artifact set (Voss thread) |
| P1-CDN-04 | `vpn_auth_log_q2.csv` | CSV | CO | Sanctioned VPN concentrator auth log — shows *normal* activity only; the exfil host is conspicuously not in it | Corroborates that theft bypassed official remote access |
| P1-CDN-05 | `noc_shift_ticket_4471.txt` | TXT | CO | NOC ticket Apr 9 (Voss on shift): bandwidth anomaly noted, closed same shift as "backup traffic — no action." Written by D. Voss | Interview lead (Voss); becomes damning retroactively — reads as sloppy, not sinister, in Packet 1 |
| P1-CDN-06 | `RE_client_data_incident.eml` | EML | CO | Email thread: client → Marcus Iyer → internal escalation. Iyer's replies show genuine confusion; timeline of discovery | Interview lead (Iyer); witness framework |
| P1-CDN-07 | `ap_vendor_ledger_2025.csv` | CSV | CO | Accounts-payable vendor ledger FY2025. RestonIT LLC appears among ~14 vendors — line items only, "managed IT services" | Vendor records subpoena → P2 vendor-history returns (MSP thread substrate) |
| P1-CDN-08 | `datacenter_client_list.pdf` | PDF | BE/DE | Marketing-style client roster. Padding + one decoy: a disgruntled former client with a billing dispute (dead-end suspect lane) | Deliberate dead end — tagged in instructor key |

### 3.2 Pixel Play Arcade — RANSOMWARE (folder: `pixelplay/`)

| ID | Filename | Fmt | Tier | Summary | Hook → Return |
|---|---|---|---|---|---|
| P1-PXP-01 | `README_RESTORE_FILES.txt` | TXT | MF | Ransom note (fictional strain "CRYPTLOCK-V"), demands 0.4 BTC to placeholder wallet `PACT{PLACEHOLDER-w1}`, TOX contact ID | Wallet → Thursday crypto lane (P4 exchange return traces the cluster) |
| P1-PXP-02 | `encrypted_dir_listing.txt` | TXT | MF | `dir /s` capture of office PC post-encryption: `.cryptlk` extensions, timestamps cluster 02:13–02:41 May 2 | Encryption window anchors DA timeline |
| P1-PXP-03 | `office_pc_security_events.csv` | CSV | MF | Windows security event excerpt: RDP logon May 2 01:58 from 203.0.113.61 via account `arcade_support` — an account the owner doesn't recognize | ISP subpoena on 203.0.113.61 → P2 return; `arcade_support` creation records → P2 victim production (fingerprint set) |
| P1-PXP-04 | `FW_ransomware_help.eml` | EML | CO | Owner's panicked email to their insurance broker; mentions considering payment, asks "how do we even buy bitcoin"; mentions "our IT guy set everything up years ago" | FoA lane (payment consideration); soft vendor pointer without naming |
| P1-PXP-05 | `quickbooks_vendor_export.csv` | CSV | CO | Vendor payment export. RestonIT LLC: recurring small invoices 2024–2025, then nothing | Vendor subpoena substrate; the *stop* date matters later, unremarkable now |
| P1-PXP-06 | `pos_daily_summary_may.csv` | BE | BE | POS revenue summaries — shows business impact, small dollar loss. Grounds the "non-critical, low priority" triage teaching point | Triage exercise fodder (SA Monday AM) |
| P1-PXP-07 | `local_pd_report_2026-05123.pdf` | PDF | CO | Huntsville PD incident report — owner called local police first. Officer narrative, no follow-up | TFO lane: local report retrieval + deconfliction hook → P2 local records return |

### 3.3 Dogwood Hotel — BEC (folder: `dogwood/`)

| ID | Filename | Fmt | Tier | Summary | Hook → Return |
|---|---|---|---|---|---|
| P1-DGW-01 | `invoice_payment_update.eml` | EML | MF | Spoofed "vendor" email (linen supplier lookalike domain) instructing banking change. **Full headers** — originating IP 203.0.113.148, lookalike domain registered 3 weeks prior | Email-provider legal process + WHOIS/registrar subpoena → P2 provider & registrar returns |
| P1-DGW-02 | `wire_confirm_0317.pdf` + `wire_confirm_0324.pdf` | PDF ×2 | MF | Two outbound wire confirmations, $48,200 and $61,750, to a fictional regional bank account | Bank subpoena (beneficiary account) → P2 financial return — FoA's richest Tuesday lane |
| P1-DGW-03 | `mailbox_audit_export.csv` | CSV | MF | Email tenant audit log: inbox forwarding rule created on the AP manager's mailbox Feb 28, external logins from 203.0.113.148 | Tenant/provider production → P2 login-history return; rule-creation date anchors compromise window |
| P1-DGW-04 | `ap_thread_linen_supply.eml` | EML | CO | The real AP email thread showing how the fraud read as routine; the genuine vendor's later "we never sent that" reply | Witness framework; wire-recall timeline |
| P1-DGW-05 | `recall_request_firstnational.pdf` | PDF | CO | Hotel's bank recall attempt — partial recovery of wire 2, wire 1 gone | FoA: funds-flow starting point |
| P1-DGW-06 | `it_services_agreement_2024.pdf` | PDF | CO | Signed managed-services agreement with RestonIT LLC — the one place RestonIT appears as more than a ledger line, because a contract is what a BEC victim would pull when asking "who has admin on our email?" Content is boilerplate; no significance framing | Strongest single vendor hook — production of RestonIT engagement records → P2/P3 |
| P1-DGW-07 | `gm_incident_memo.pdf` | PDF | CO | General manager's internal memo reconstructing events for ownership — human-voice narrative, minor honest inaccuracies (teaching: witness accounts vs. logs) | IA/SA: source-reliability exercise |
| P1-DGW-08 | `staff_phishing_test_2025.csv` | BE/DE | DE | Old phishing-awareness test results; one employee failed twice. Decoy insider lane — that employee is innocent | Dead end — tagged in instructor key |

### 3.4 Redstone Memorial Hospital — DETECTED INTRUSION (folder: `redstone_memorial/`)

| ID | Filename | Fmt | Tier | Summary | Hook → Return |
|---|---|---|---|---|---|
| P1-RMH-01 | `edr_alert_export_0521.json` | JSON | MF | EDR alert bundle May 21: credential-use anomaly — service account `svc_backup_rst` authenticated to three servers at 03:12, first activity ever recorded for that account | Victim production: account-creation records for `svc_backup_rst` → P2 **fingerprint centerpiece** |
| P1-RMH-02 | `it_containment_ticket_9902.txt` | TXT | MF | IT ticket: account disabled 03:40 same night, sessions killed. Note: "nobody on the team knows what this account is. It predates all of us." | The unexplained-account thread, stated in a victim's own voice — the closest Packet 1 comes to the pattern, still fully inside the ceiling |
| P1-RMH-03 | `dc_auth_log_excerpt.csv` | CSV | MF | Domain controller auth excerpt: the 03:12 logons, source IP 192.0.2.190 (internal VPN pool), preceded by a VPN association from 203.0.113.61 | **Same external IP as PixelPlay (P1-PXP-03).** Neither file remarks on it — the overlap exists only for students who correlate. ISP subpoena → P2 |
| P1-RMH-04 | `hipaa_risk_memo.pdf` | PDF | CO | Compliance officer's memo: assessment that no PHI was accessed pre-containment. Grounds severity/urgency discussion | IA: consequence framing; SA: prioritization vs. PixelPlay |
| P1-RMH-05 | `vendor_po_history.csv` | CSV | CO | Purchase-order history; RestonIT LLC present 2024–2025 ("network support — imaging wing project") | Vendor subpoena substrate |
| P1-RMH-06 | `helpdesk_email_thread.eml` | EML | MF | Staff thread the morning after detection: one nurse recalls a "weird call from IT support" ~Jul 8 asking her to confirm the remote-access portal address; she forwarded her original note to the helpdesk at the time — **preserving the caller ID number** (fictional VoIP DID) | Phone-records subpoena on the DID → P2 VoIP provider return: burner VoIP account, registration email resurfaces in P3 Black Harbor data on the **BRKR_RU side** (buyer pre-intrusion recon — strengthens buyer attribution, not Reston) |
| P1-RMH-07 | `network_diagram_2023.pdf` | BE | BE | Outdated network diagram from a 2023 audit — realistic clutter; also quietly documents that the imaging-wing segment RestonIT touched has domain-admin-adjacent service paths (payoff readable only in retrospect) | Background corroboration for P3 |

---

## 4. Cross-victim design notes (instructor key only)

- **The only Packet 1 cross-victim signal is 203.0.113.61** (PixelPlay RDP source = Redstone Memorial VPN source). Two victims, one IP, zero commentary. This is the Tier-1→Tier-2 bridge: a squad that catches it Monday is ahead; the Packet 2 ISP return hands it to everyone else Tuesday.
- **RestonIT surface area, ranked by visibility:** Dogwood (signed contract) > Redstone Memorial (named PO project) > CyberDyne (ledger line) > PixelPlay (unnamed "IT guy" + vendor export). Deliberate gradient — no single file screams vendor; four quiet appearances converge only under Tuesday's correlation taskings.
- **Dormant-account edge visibility:** Only RMH shows the pattern's edge explicitly ("predates all of us"). PixelPlay's `arcade_support` is unrecognized but unremarked. CyberDyne's is hidden entirely (appliance, not account — surfaces P3). Dogwood's compromise vector reads as pure phishing until P2's tenant return shows the initial access predated the phish.
- **Incident-type → role gravity (Monday):** CyberDyne → DA/SA · PixelPlay → SA triage + FoA/crypto seed · Dogwood → FoA/TFO · RMH → IA + urgency framing.

## 5. Central IOC registry (single source of truth for content generation)

| IOC | Type | Role in case | Appears in |
|---|---|---|---|
| 198.51.100.23 | Ext. IP | Exfil destination (foreign VPS) | P1-CDN-02 → P2 ISP return → Wed AM foreign return |
| 203.0.113.61 | Ext. IP | BRKR_RU operational IP | P1-PXP-03, P1-RMH-03 → P2 ISP return |
| 203.0.113.148 | Ext. IP | BEC sender/login IP | P1-DGW-01, P1-DGW-03 → P2 provider return |
| 10.14.8.77 | Int. IP | Off-books appliance (Voss) | P1-CDN-02/03 gap → P3-AM |
| 192.0.2.190 | Int. IP | RMH VPN pool assignment | P1-RMH-03 |
| `svc_backup_rst` / `arcade_support` | Accounts | Reston-provisioned dormant accounts | P1-RMH-01/02, P1-PXP-03 → P2 creation-record returns |
| `PACT{PLACEHOLDER-w1}` | BTC wallet | Ransom wallet → proceeds trace | P1-PXP-01 → P4 |
| CRYPTLOCK-V | Malware name | Fictional strain | P1-PXP-01/02 |
| 256-555-0147 | VoIP DID | BRKR_RU vishing burner (pre-intrusion recon) | P1-RMH-06 → P2 VoIP return → P3 BRKR_RU registration email |

## 6. Decisions — RESOLVED 2026-07-21

1. **Timeline:** shifted for Sept 21–25 cohort; locked in §2.
2. **P1-RMH-06:** live corroboration (MF). Chain: DID → P2 VoIP return → P3 BRKR_RU linkage.
3. **Loss figures:** locked in §2.
4. **File count:** 30 confirmed (8/7/8/7).
