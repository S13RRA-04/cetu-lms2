# PACT Rebuild — Packet 3 Manifest: "The Broker"
**Drop day:** Wednesday AM (Day 3) · **Status:** DESIGN + GENERATED
**Classification note:** Device-native and entity-produced files carry NO banners. Two FBI work products (Black Harbor collection cover; the Day 3 command post set) carry UNCLASSIFIED//FOUO//PACT banners.

---

## 1. Packet-wide rules

1. **Inference ceiling (Packet 3 = "The Broker"):** BRKR_AL → Reston attribution is **buildable but NOT stated**. The packet supplies sufficient material to argue probable cause; no file asserts the identity. Persona resolution is SOS work; the money overlay is FoA work; the provisioning-signature tie is DA/IA work. Full attribution + the identity-confirming returns are held for Packet 4 (Thursday) — the PM search is what converts Wednesday's circumstantial case into direct evidence.
2. **SaturnV blackout:** SaturnV Mart appears in NO Packet 3 file. First appearance is on devices seized Wednesday PM (surfaced in Packet 4 + the KCR notification inject). RestonIT's client roster is therefore NOT in this packet — it lives on the seized office machine.
3. **Predicate discipline:** Every return names its predicate (the Packet 1/2 artifact that exposed the entity → instrument → responding party). Recorded in §3.
4. **Provenance discipline for collection:** Black Harbor material is undercover / online-covert-employee (OCE) product, NOT legal process. The collection cover memo documents how it was obtained — this is the moot-court "how did we get this?" answer for every marketplace file.
5. IP/token/all-digital rules unchanged. New wallet placeholder `PACT{PLACEHOLDER-w3}` = BRKR_AL (seller) receiving wallet.

---

## 2. Attribution-build primitives (instructor key only)

Packet 3 extends the earlier primitives and adds the seller-side threads. None stated; each requires overlay.

| Primitive | Value | Ties together | Role lane |
|---|---|---|---|
| Provisioning signature (extended) | `RMM-Agent/4.7` | Packet 2 dormant-account creation + Packet 3 appliance management sessions | DA / IA |
| Buyer identity (closed loop) | `d.kort92@protonrelay.example` / `PACT{PLACEHOLDER-w2}` | Packet 2 (VPN+VoIP+domain) + Packet 3 Black Harbor BRKR_RU account + Northwind lessee | SOS / FoA |
| Market-to-victim match | listing characteristics | Black Harbor listings ↔ the four victims' compromise profiles (Packets 1–2) | IA / SOS |
| Seller proceeds | `PACT{PLACEHOLDER-w3}` → CoinBridge off-ramp → RestonIT banking anomalies | crypto export + RestonIT bank return | FoA |
| Appliance provenance | Voss install + RMM-Agent co-option + Northwind tunnel | appliance config/session/provenance | SA / DA |

**What stays UNBUILT until Thursday:** the CoinBridge KYC return and seized-device contents that put a name on BRKR_AL. Wednesday ends with a strong circumstantial case (common vendor + shared provisioning signature + market listings matching victims + proceeds flowing toward RestonIT-linked crypto) — enough to argue PC for the search, not enough to skip it.

---

## 3. File-by-file spec (folder: `packet3/`)

### Foreign priming return (first international response — Wed AM)

| ID | Filename | Fmt | Tier | Predicate | Summary |
|---|---|---|---|---|---|
| P3-INTL-01 | `northwind_mlat_partial_return.pdf` | PDF | MF | P2-NET-01 (Estonia allocation) → MLAT/EU legal assistance → Northwind Datacenters OÜ | PARTIAL return. VPS at 198.51.100.23 leased to account registered `d.kort92@protonrelay.example`, paid via `PACT{PLACEHOLDER-w2}`; VM received ~360 GB inbound Jun 15–18 (the CDN exfil). Some records provided; **destination-of-data and payment-history items marked PENDING** (realistic partial). Confirms the buyer's exfil endpoint. |

### CyberDyne appliance forensic set (resolves 10.14.8.77 — Voss thread)

| ID | Filename | Fmt | Tier | Predicate | Summary |
|---|---|---|---|---|---|
| P3-APP-01 | `cdn_appliance_config_export.txt` | TXT | MF | P1-CDN-03 (host absent from inventory) → supplemental production → CyberDyne | Off-books VPN appliance config. Shows Voss's original shadow-IT setup (2025-05) **plus** an added persistent tunnel to 198.51.100.23 and remote management enrollment (2025-09). Two eras in one config = the co-option. |
| P3-APP-02 | `cdn_appliance_session_log.csv` | CSV | MF | (same production) | Appliance sessions: management logins tagged **`RMM-Agent/4.7`** (same signature as Packet 2 account creation) + the exfil tunnel flows Jun 15–18. Dormant Sep 2025→Jun 2026 (staged access, unlabeled). |
| P3-APP-03 | `cdn_appliance_provenance_record.pdf` | PDF | CO | (same production) | CyberDyne's discovery record: device found physically concealed in Rack C3; install attributed to NOC tech **D. Voss**; access history lists everyone with reach to that rack/segment during the window (Voss + the MSP engagement). States facts, draws no conclusion → Voss interview lead; MSP inference left to students. |

### RestonIT financial return

| ID | Filename | Fmt | Tier | Predicate | Summary |
|---|---|---|---|---|---|
| P3-FIN-01 | `restonit_business_banking_return.pdf` | PDF | MF | P2 vendor overlay (RestonIT common vendor) → subpoena → RestonIT's bank | Cover on RestonIT LLC operating account. Legitimate MSP revenue **plus** recurring inbound deposits from a crypto exchange and unusually large owner draws inconsistent with stated MSP income. FoA lifestyle/discrepancy lane (partial — personal finances come Thursday from seizure). |
| P3-FIN-02 | `restonit_bank_transactions.csv` | CSV | MF | (same return) | Transaction ledger: client payments **including the four victims' businesses** (corroborates the vendor tie in the money) + CoinBridge-linked inbound deposits + owner draws. |

### Black Harbor Exchange collection (OCE product — provenance-marked)

| ID | Filename | Fmt | Tier | Predicate | Summary |
|---|---|---|---|---|---|
| P3-BH-00 | `blackharbor_collection_cover.pdf` | PDF (BANNER) | MF | Undercover/OCE operation → FBI collection | Cover memo: how the marketplace material was obtained (authorized online covert employee), capture dates, authenticity/hashing note. The "how did we get this" answer for moot court. |
| P3-BH-01 | `blackharbor_listings_brkr_al.pdf` | PDF | MF | (collection) | Four access listings by seller **BRKR_AL**, described by characteristics that MATCH the four victims (DC/colo mgmt-plane; regional hospital AD service acct; hospitality O365 global admin; SMB entertainment local-admin/RDP). Priced, dated Mar–Apr 2026. Never names victims. |
| P3-BH-02 | `blackharbor_vendor_profile_brkr_al.pdf` | PDF | CO | (collection) | BRKR_AL seller profile: join 2024, reputation, PGP key + UID, contact handle. Contains the opsec slip SOS pivots on (handle/PGP UID reuse) — resolves toward Reston only via OSINT overlay, not stated. |
| P3-BH-03 | `blackharbor_transaction_messages.txt` | TXT | MF | (collection) | Captured BRKR_AL ↔ **BRKR_RU** DMs/escrow: purchase of the four accesses, credential delivery matching the dormant accounts/appliance, timing (provision→sale→intrusion). BRKR_RU account carries `d.kort92` + `PACT{PLACEHOLDER-w2}` → closes the buyer loop from Packet 2. |

### Cryptocurrency records

| ID | Filename | Fmt | Tier | Predicate | Summary |
|---|---|---|---|---|---|
| P3-CRY-01 | `crypto_cluster_analysis.pdf` | PDF | MF | Blockchain analytics (generic commercial platform, tool-agnostic) | Cluster/flow graph across `PACT{PLACEHOLDER-w1/w2/w3}`: ransom wallet, BRKR_RU wallet, BRKR_AL wallet, and the CoinBridge off-ramp. Shows w2→w3 (buyer paying seller) and w3→exchange. Platform clusters but does not attribute identity. |
| P3-CRY-02 | `crypto_transactions_export.csv` | CSV | CO | (same) | Raw transaction export (addresses, amounts, timestamps) for the cluster — DA/FoA parse lane. |

### Orientation

| ID | Filename | Fmt | Summary |
|---|---|---|---|
| P3-CP | `00_COMMAND_POST_Day3.md` / `.pdf` | MD + PDF (BANNER) | Orients to the forensic drop; tasks PC development WITHOUT stating the target; briefs the PM KCR search mechanics; primes duty-to-warn ("remain alert for additional victims / ongoing activity; notify CP immediately") — the SaturnV inject primer, SaturnV unnamed. |

**Total: 12 evidence files + command post set.**

---

## 4. Ceiling audit (instructor key only)

- **No file names BRKR_AL as Reston.** SOS must pivot the PGP/handle slip; FoA must overlay w3→CoinBridge→RestonIT banking; the CoinBridge KYC that would confirm it is deliberately held for Thursday.
- **Appliance provenance states facts, not conclusions.** Voss is named as installer (CyberDyne's own finding); RestonIT is not named as the co-opting operator — that's the RMM-Agent overlay, left to students.
- **Market listings never name victims.** Matching is by compromise characteristics — requires having understood Packets 1–2.
- **SaturnV absent.** Verified: no client roster, no fifth listing, no forward reference.
- **Dormancy shown, not labeled** on the appliance (Sep 2025 enrollment → Jun 2026 use) exactly as with the Packet 2 accounts.

## 5. New IOCs (append to registry)

| IOC | Type | Role | First appears |
|---|---|---|---|
| `PACT{PLACEHOLDER-w3}` | BTC wallet | BRKR_AL (seller) proceeds | P3-CRY-01/02 → Thu trace |
| BRKR_AL | Marketplace handle | Seller (access broker) — resolves to Reston (Thu) | P3-BH-01/02/03 |
| RMM-Agent/4.7 (on appliance) | Tool signature | Ties appliance to Packet 2 provisioning | P3-APP-02 |
| CoinBridge (as BRKR_AL off-ramp) | Exchange | Seller cash-out → KYC return Thu | P3-CRY-01, P3-FIN-02 |
| Rack C3 concealed appliance | Device | CDN persistent-access mechanism | P3-APP-01/02/03 |

## 6. Flaggable invented specifics
- BRKR_AL join year (2024), listing prices, PGP UID slip content — fictional, tune to taste.
- Appliance model/vendor name is generic; swap if you want a specific make.
- The Voss-installed-then-co-opted mechanism is the canonical CDN vector; confirm it matches your KCR scene build for the appliance.
