`UNCLASSIFIED//FOUO//PACT`

# COMMAND POST INSTRUCTION SET — DAY 3

_PACT — Practical Applications to Cyber Threats · Command Post Instruction Set_

- **To:** Assigned Cyber Squad
- **From:** Command Post / Case Management (SSA)
- **Re:** Forensic development and field operation
- **Evidence Drop:** Packet 3 — forensic, financial, and collection material

## 1. SITUATION
Your correlation work has driven this investigation to a forensic and financial phase. Today's drop contains host and network forensic material, financial records, captured marketplace collection, cryptocurrency records, and a first partial response to your international request. The morning's objective is to develop this material to the point of a probable-cause determination. This afternoon the squad conducts a field search operation at the Kinetic Cyber Range, predicated on the case you build this morning.

## 2. TODAY'S DROP
Material spans several sources; treat each according to how it was obtained.

- **`Appliance forensics`** — configuration, session log, and discovery record for the previously unidentified device on a victim network
- **`Financial records`** — subpoenaed business banking records and transaction history
- **`Marketplace collection`** — captured listings, a seller profile, and message/escrow content — obtained by undercover collection, not legal process
- **`Cryptocurrency`** — analytics cluster report and a raw transaction export
- **`International`** — a partial response to your foreign request — some records provided, others pending

The marketplace material was obtained through undercover collection. Be prepared to articulate its provenance; any mapping from it to known facts is your analytic work product, not a given.

## 3. STANDING ORDERS
- Apply forensic rigor: preserve provenance, note hashes where provided, and do not alter source material. Distinguish what an artifact proves from what it suggests.
- Build any probable-cause determination on articulable evidence. Tie every assertion to a specific artifact. Do not label an actor or identity your evidence does not yet support.
- Where a tool signature, an indicator, or a financial flow appears in more than one place, treat the recurrence as a lead to be corroborated, not a conclusion.
- FIELD OPERATION — evidence handling: on scene this afternoon, maintain strict chain of custody. Photograph and document before collecting. Follow the operation order issued at the pre-operation brief.
- FIELD OPERATION — remain alert for indications of additional victims or active, ongoing criminal activity. If you encounter evidence that someone is being harmed right now, or is about to be, STOP and notify the command post immediately. Time-sensitive threats take priority over evidence collection sequence.

## 4. SQUAD OBJECTIVES
Morning, by end of block:

1. A completed forensic analysis of the appliance: what it is, when and how it was changed, and what it was used for.
2. A financial picture: legitimate versus anomalous flows, and where the money appears to move.
3. A mapping of the marketplace material to the known facts of the case, documented as analytic work product.
4. A cryptocurrency flow picture across the address set.
5. A consolidated probable-cause determination sufficient to support a search — the basis for the afternoon operation.
6. An updated international-evidence tracker reflecting the partial return.

Afternoon: execute the field search operation per the operation order, each role performing its assigned function on scene.

## 5. WORKSHOP / OPERATION FLOW
- Morning block: individual role taskings, then squad synthesis into the probable-cause package.
- Pre-operation brief: the operation order and role assignments for the search are issued here, after your morning synthesis.
- Field operation: conduct the search; collect, document, and preserve.

## 6. CLOSEOUT AND HANDOFF
This morning's probable-cause package is the basis for the afternoon search. Whatever you collect this afternoon — and the after-action review of how the operation ran — is what you will analyze tomorrow. Document custody completely; defects created today become problems in tomorrow's analysis and in the moot court.

## 7. DO NOT
- Do not alter, contaminate, or work from un-preserved source material.
- Do not overstate probable cause; name the artifact behind every element.
- Do not disregard indications of ongoing harm in the field. When in doubt, notify the command post.

`UNCLASSIFIED//FOUO//PACT`
