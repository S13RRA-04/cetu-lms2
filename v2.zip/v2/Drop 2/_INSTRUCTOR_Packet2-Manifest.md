# PACT Rebuild — Packet 2 Manifest: "The Pattern"
**Drop day:** Tuesday AM (Day 2) · **Status:** DESIGN + GENERATED
**Classification note:** No banners on any file. Every file is an entity-produced legal-process return or public record. FBI work products (the returns index, correlation matrices) are STUDENT deliverables, not packet files.

---

## 1. Packet-wide rules

1. **Return-predicate discipline:** Every file names (a) the Packet 1 artifact that exposed the entity, (b) the legal instrument that reaches it, (c) the responding entity. A return with no Packet 1 predicate does not ship. Recorded per-file in §3.
2. **"Requested vs. caught" beat:** The packet is static — it cannot respond to each squad's actual request list. Packet 1 seeds hooks strongly enough that competent request lists converge here. Two returns (flagged ★) are ones a squad commonly *misses* — the case agent "caught" them — for the Tuesday-morning teachable beat.
3. **Inference ceiling (Packet 2 = "The Pattern"):** Cross-victim correlation is INTENDED and discoverable. What stays unlabeled: (a) that the common vendor is the perpetrator, (b) the four-phase lifecycle / dormancy framing, (c) any IAB label, (d) any single file asserting "these victims are connected." Every correlation below requires students to overlay ≥2 files.
4. **Foreign discipline:** Tuesday PM is International Evidence — REQUEST, don't receive. The packet contains the foreign *indicator* (198.51.100.23 resolves to a foreign host) but NOT the foreign substance (subscriber/session records). Those return Wednesday AM as priming. Domestic returns (VeilStream, US banks, US providers) return here in full.
5. IP discipline, all-digital rule, token placeholders, tier tags (MF/CO/DE/BE) — unchanged from Packet 1.

---

## 2. The four buyer-side correlation primitives (instructor key only)

Packet 2 seeds four independent threads that each tie ≥2 artifacts. No file states them; students build them. This is the "three independent directions" reveal.

| Primitive | Value | Ties together | Role lane |
|---|---|---|---|
| Shared exit IP | 203.0.113.61 | PixelPlay RDP (P1) + RMH VPN (P1) + VeilStream session log (P2) | DA / IA |
| Shared reg email | `d.kort92@protonrelay.example` | VeilStream VPN subscriber (P2) + burner VoIP (P2) | SOS / DA |
| Shared crypto wallet | `PACT{PLACEHOLDER-w2}` | VeilStream payment (P2) + lookalike-domain registration payment (P2) | FoA |
| Shared provisioning identity | `rmm_admin` (3 formats) | RMH AD (P2) + PixelPlay local (P2) + Dogwood tenant (P2) account-creation records | DA / IA |

**Seller-side thread (held looser, resolves P3):** RestonIT LLC appears across all four victims' vendor records (P1 AP ledgers ×3 + Dogwood signed contract). Overlaying `rmm_admin` account-creation dates against RestonIT engagement dates is the bridge from buyer-infrastructure to the MSP — but Packet 2 never closes it. The Alabama SOS record (P2-VEND-01) confirms the entity and names Alex M. Reston as principal; it does NOT label RestonIT as the intruder.

---

## 3. File-by-file spec (folder: `packet2/`)

Grouped by responding entity. 12 files.

### Network infrastructure returns

| ID | Filename | Fmt | Tier | Predicate chain | Summary |
|---|---|---|---|---|---|
| P2-NET-01 | `isp_return_198-51-100-23.pdf` | PDF | MF | P1-CDN-02 (exfil dst) → subpoena to block-holder ISP → US ISP | 198.51.100.23 is sub-allocated to **Northwind Datacenters OÜ, Tallinn, Estonia**. Subscriber detail requires request to the foreign provider. **FOREIGN INDICATOR** — drives Tue PM international request; substance returns Wed AM. |
| P2-NET-02a | `veilstream_subscriber_return.pdf` | PDF | MF | P1-PXP-03 + P1-RMH-03 (shared 203.0.113.61) → subpoena → VeilStream LLC (US VPN, WY) | Exit IP 203.0.113.61 assigned to subscriber **VS-88213**. Reg email `d.kort92@protonrelay.example`; paid via BTC from `PACT{PLACEHOLDER-w2}`; real-source logging minimal (anonymized upstream). |
| P2-NET-02b | `veilstream_connection_log.csv` | CSV | MF | (same return, data attachment) | Session records for VS-88213 on exit 203.0.113.61. Sessions align with PixelPlay (Jul 11 01:55–02:45) and RMH (Jul 30 03:05–03:45) intrusion windows, among decoy sessions. **Overlay-to-victim = the correlation; log alone names no victim.** |

### BEC infrastructure returns (Dogwood)

| ID | Filename | Fmt | Tier | Predicate chain | Summary |
|---|---|---|---|---|---|
| P2-EML-01 | `emailprovider_return_lookalike.pdf` | PDF | MF | P1-DGW-01 (spoof headers) → 2703(d) + subpoena → email provider | Account `accounts@magnolia-linensupply.example` created May 1 2026; creation + login IPs 203.0.113.148; thin recovery contact. Confirms lookalike infra predates the May 20 phish. |
| P2-EML-02 | `registrar_whois_return_lookalike.pdf` | PDF | CO | P1-DGW-01 (lookalike domain) → subpoena → registrar | `magnolia-linensupply.example` registered May 1 2026, privacy-protected registrant, registration IP 203.0.113.148, **paid via BTC from `PACT{PLACEHOLDER-w2}`** (same wallet as VeilStream — crypto correlation). |

### Vishing return (RMH) ★ commonly-missed

| ID | Filename | Fmt | Tier | Predicate chain | Summary |
|---|---|---|---|---|---|
| P2-VOIP-01 ★ | `voip_provider_return_2565550147.pdf` | PDF | MF | P1-RMH-06 (preserved DID) → subpoena → VoIP provider | DID 256-555-0147 = burner VoIP acct created Jul 6, **reg email `d.kort92@protonrelay.example`** (same as VeilStream — email correlation). CDRs show the Jul 8 call to nurse D. Osei + a call to RMH's remote-portal help line (buyer pre-intrusion recon). |

### Financial returns (Dogwood BEC money)

| ID | Filename | Fmt | Tier | Predicate chain | Summary |
|---|---|---|---|---|---|
| P2-FIN-01a | `ozarkvalley_bank_return.pdf` | PDF | MF | P1-DGW-02/05 (beneficiary acct) → subpoena → Ozark Valley Community Bank | Beneficiary acct 4471820963 opened remotely Apr 2026; KYC identity **"Raymond T. Colson"** (synthetic/stolen — DOB/SSN mismatch noted); both Dogwood wires received; account since closed, fraud-flagged. |
| P2-FIN-01b | `ozarkvalley_transactions.csv` | CSV | MF | (same return, data attachment) | Transaction ledger: wire-ins ($48,200 May 26; $61,750 Jun 2), rapid ACH-out to two mule accounts, cash withdrawals, and one $40,000 transfer to crypto exchange **CoinBridge** (seeds Thu crypto/laundering lane). |

### Victim supplemental productions — account-creation fingerprint (the centerpiece)

| ID | Filename | Fmt | Tier | Predicate chain | Summary |
|---|---|---|---|---|---|
| P2-ACCT-01 | `rmh_ad_account_export.csv` | CSV | MF | P1-RMH-01/02 (`svc_backup_rst`) → supplemental production request → RMH | AD object: whenCreated **2025-09-18**, createdBy **`RMH\rmm_admin`**, memberOf Backup Operators + a domain-admin-adjacent group (over-permissioned), lastLogon 2026-07-30. Creation→use gap = dormancy (unlabeled). |
| P2-ACCT-02 | `pixelplay_local_accounts.txt` | TXT | MF | P1-PXP-03 (`arcade_support`) → supplemental production → PixelPlay | Local SAM export: `arcade_support` created **2025-10-15** by **`rmm_admin`**, member of Administrators + Remote Desktop Users, last logon 2026-07-11. |
| P2-ACCT-03 | `dogwood_tenant_admin_audit.csv` | CSV | MF | P1-DGW-03 (May 9 forwarding rule) → tenant supplemental production → Dogwood | Cloud tenant admin log: service acct `svc_mailmgmt` created **2025-11-12** by **`rmm_admin@dogwoodhotel.example`** (UPN format — same principal, different format = entity-resolution exercise); holds global-admin-equivalent; **this account created the May 9 forwarding rule** — ties BEC to a dormant provisioned account, not just phishing. |

### Seller-entity public record ★ commonly-missed

| ID | Filename | Fmt | Tier | Predicate chain | Summary |
|---|---|---|---|---|---|
| P2-VEND-01 ★ | `alabama_sos_restonit_llc.pdf` | PDF | CO | SOS Tuesday tasking (RestonIT noticed in ≥1 AP ledger) → public records → AL Secretary of State | RestonIT LLC entity record: formed 2019, member/principal **Alex M. Reston**, registered agent, principal address 4155 Commerce Square Suite 214, Huntsville AL. Entity confirmation only — does NOT label RestonIT as intruder. |

---

## 4. Ceiling audit (instructor key only)

- **No file names a perpetrator.** SOS record names Reston as an LLC principal — a neutral public fact, not an accusation.
- **No file asserts cross-victim linkage.** VeilStream log lists sessions with timestamps; it never says "these hit PixelPlay/RMH." The overlay is student work.
- **Dormancy is shown, not labeled.** Account-creation records carry whenCreated + lastLogon; the ~9–11 month gap is visible but never called "dormancy" or "staged access."
- **rmm_admin is the discoverable fingerprint, not a label.** Same provisioning identity across three victims in three formats. Linking rmm_admin → RestonIT requires overlaying creation dates against RestonIT engagement dates (P1 ledgers/contract) — held for students, not stated.
- **Foreign substance withheld.** P2-NET-01 gives allocation only; Northwind subscriber/session records are Wednesday-AM priming, not in this packet.

## 5. New IOCs added this packet (append to central registry)

| IOC | Type | Role | First appears |
|---|---|---|---|
| Northwind Datacenters OÜ (Tallinn, EE) | Foreign host | Data-exfil destination provider | P2-NET-01 → Wed AM foreign return |
| VeilStream LLC / VS-88213 | US VPN + subscriber | BRKR_RU operational anonymization | P2-NET-02a/b |
| `d.kort92@protonrelay.example` | Email | BRKR_RU reg email (VPN + VoIP) | P2-NET-02a, P2-VOIP-01 |
| `PACT{PLACEHOLDER-w2}` | BTC wallet | BRKR_RU payment wallet (VPN + domain) | P2-NET-02a, P2-EML-02 → Thu crypto |
| Ozark Valley acct 4471820963 / "Raymond T. Colson" | Bank acct / identity | BEC beneficiary (synthetic ID) | P2-FIN-01a/b |
| CoinBridge (exchange) | Crypto exchange | Fiat→crypto laundering off-ramp | P2-FIN-01b → Thu |
| `rmm_admin` (3 formats) | Provisioning identity | Dormant-account creator across 3 victims | P2-ACCT-01/02/03 |
| `svc_mailmgmt` | Tenant service acct | Dogwood dormant provisioned account (created BEC rule) | P2-ACCT-03 |

## 6. Notes / flaggable invented specifics
- Foreign host country = **Estonia** (EU, MLAT-reachable, slow-but-cooperative) — sets the Tue PM international-request tasking as an MLAT/EU-legal-assistance exercise. Swap country if you want a non-cooperative posture instead.
- Synthetic beneficiary identity name "Raymond T. Colson", exchange "CoinBridge", VPN "VeilStream LLC (WY)" — all fictional, swap freely.
- `PACT{PLACEHOLDER-w2}` is a placeholder; Cody mints the real wallet.
