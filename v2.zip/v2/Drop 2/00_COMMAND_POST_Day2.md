`UNCLASSIFIED//FOUO//PACT`

# COMMAND POST INSTRUCTION SET — DAY 2

_PACT — Practical Applications to Cyber Threats · Command Post Instruction Set_

- **To:** Assigned Cyber Squad
- **From:** Command Post / Case Management (SSA)
- **Re:** Legal-process returns and correlation
- **Evidence Drop:** Packet 2 — returns and public records

## 1. SITUATION
Yesterday your squad triaged four complaints and identified investigative and legal-process requests. Responses have begun returning from the served entities and from public records. Today's drop consists of those returns.

Some returns answer requests your squad identified. Others were initiated by the command post based on the same intake — review them regardless of whether you asked for them, and note where your own request list had gaps.

## 2. TODAY'S DROP
Returns are organized by responding entity, not by victim — because that is how legal process comes back. A subpoena to a bank produces a bank's response; it does not sort itself by which matter it touches. Sorting that out is your work.

- **`Network / hosting returns`** — ISP allocation and VPN subscriber/session records
- **`Business-email-compromise infrastructure`** — email provider and domain registrar returns
- **`Telecom`** — VoIP provider subscriber and call records
- **`Financial`** — bank account records and transaction history
- **`Victim supplemental productions`** — account records the victims produced on further request
- **`Public record`** — state business-entity filing

## 3. STANDING ORDERS
- Correlate deliberately. Assess whether and how these returns relate to one another and to the four matters. Support every proposed linkage with specific artifacts — a shared indicator is a lead, not a conclusion.
- Distinguish what a record proves from what it merely suggests. Say which is which.
- Some evidence sits outside the United States. Identify it, and determine what process is required to obtain it. Do not assume it will return quickly, and do not assume it is out of reach.
- Continue the request tracker: mark which requests are answered, which remain pending, and which new requests today's returns make necessary.

## 4. SQUAD OBJECTIVES (by closeout)
1. A relationship assessment: are these four matters connected? If so, on exactly what evidence? State your confidence and what would raise or lower it.
2. A consolidated timeline drawn across the returns.
3. A financial-flow picture from the banking returns: where the money went and what remains traceable.
4. An international-evidence request package: what is abroad, what process each item requires, and priority order.
5. An updated legal-process request tracker.

## 5. WORKSHOP FLOW
- Morning block works the domestic returns and the correlation question.
- Afternoon block works the international dimension: identify foreign-held evidence and build the request package. Expect nothing back today on those requests.
- Role-specific taskings are issued at the start of each block.

## 6. CLOSEOUT AND HANDOFF
Your relationship assessment, timeline, financial-flow picture, and international request package feed tomorrow. Tomorrow moves to host and network forensics and a field exercise; the cleaner your correlation work today, the sharper you will be on scene.

## 7. DO NOT
- Do not overstate linkage. Name the artifact behind every connection you assert.
- Do not label actors or entities beyond what the evidence supports.
- Do not treat foreign evidence as either unobtainable or instantly available.

`UNCLASSIFIED//FOUO//PACT`
