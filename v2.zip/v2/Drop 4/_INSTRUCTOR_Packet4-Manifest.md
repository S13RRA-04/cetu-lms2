# PACT Rebuild — Packet 4 Manifest: "The Case"
**Drop day:** Thursday AM (Day 4) · **Status:** DESIGN + GENERATED
**Classification note:** FBI work products (evidence inventory, examiner extraction reports, photo log) carry UNCLASSIFIED//FOUO//PACT banners. Extracted subject files and entity returns are device-native → NO banners.

---

## 1. Packet-wide rules

1. **Source:** Every file is either (a) a forensic extraction from a device seized Wednesday PM at KCR, (b) a copy of a physical item seized on scene, or (c) an entity return held from Packet 3. Nothing here is un-predicated.
2. **Ceiling — lifted, with one reservation:** Evidence is now direct and sits on the subject's own devices. Examiner reports and extracted files state **findings**, not the ultimate conclusion. No packet file declares "Alex Reston is BRKR_AL and committed these offenses" — that attribution is the students' Thursday-AM synthesis (Attribution workshop), and the conclusion lives in the instructor answer key. The subject's own records (access matrix, wallet, keyring) make the conclusion unavoidable; students still must state and support it.
3. **SaturnV reveal:** SaturnV Mart appears for the first time here — on the seized office machine — with a **live, unsold** provisioned access. This is the duty-to-warn payoff: four victims were too late; SaturnV is preventable. Ties back to the Wednesday-PM KCR notification inject.
4. **Custody continuity:** The seized-evidence inventory is provided so the OST can reconcile it against Wednesday's on-scene custody forms. Defects introduced on scene follow their items into Thursday analysis and Friday moot court.
5. Location prefixes: RIT-OFF (office Suite 214), RIT-RES (residence). Tokens/IP/all-digital rules unchanged.

---

## 2. Thread-closure map (instructor key only)

| Thread | Closing artifact(s) | How it closes | Role lane |
|---|---|---|---|
| BRKR_AL identity | `RIT-RES_pgp_keyring_export.txt` (private key ID 0xA1C4 7E90 2B7F 11F0 — matches P3 vendor profile public key) + browser artifacts | Subject's device holds BRKR_AL's private key + Black Harbor sessions | SA / IA |
| Four-phase model | `client_access_matrix.csv` | Subject's own inventory: provision date → dormant → LISTED/SOLD → sale ref, per victim | IA / SA |
| Provisioning presence | `RIT-OFF_samsmith_service_tickets.csv` + `samsmith_phone_payment_export.csv` | Reston (tech "AR") on the backdoor visits; Sam innocent; payments corroborate dates | FoA / SA |
| Proceeds → identity | `coinbridge_kyc_return.pdf` + `RIT-RES_personal_financials.csv` | CoinBridge cash-out (PACT-w3) KYC + withdrawal to RestonIT/Reston account; lifestyle discrepancy | FoA |
| Buyer confirmation | access matrix sale refs `BH-0314` | matches P3 Black Harbor escrow date 2026-03-14 | IA / DA |
| Ongoing harm | `saturnv_client_folder_notes.txt` + matrix SaturnV row (LISTED, unsold) | live provisioned access; notification prevents 5th intrusion | SA / TFO / OST |

**Cross-packet date consistency (must hold):** matrix provisioned dates = Packet 2 account-creation dates (svc_backup_rst 2025-09-18, arcade_support 2025-10-15, svc_mailmgmt 2025-11-12, CDN appliance 2025-09-14). Sale ref BH-0314 = P3 escrow 2026-03-14. PGP key ID = P3 vendor profile. Wallet = PACT{PLACEHOLDER-w3}.

---

## 3. File-by-file spec (folder: `packet4/`)

### Custody & physical-item copies

| ID | Filename | Fmt | Tier | Summary |
|---|---|---|---|---|
| P4-EV-00 | `SEIZED_evidence_inventory.pdf` | PDF (BANNER) | MF | Itemized seizure inventory by evidence number and scene (office / residence), for OST reconciliation against on-scene custody forms. |
| P4-EV-01 | `RIT-OFF_photo_log.pdf` | PDF (BANNER) | CO | Evidence photo log: photographed physical items in place (workstation, external drive, printed pages, handwritten notebook) with evidence numbers. Copy-of-physical-artifact class. |
| P4-EV-02 | `RIT-RES_notebook_page_scan.pdf` | PDF | MF | Scanned handwritten notebook page from residence: client shorthand, a partial wallet/seed reminder, a note referencing "escrow" and buyer handle. Copy-of-physical-artifact class. |

### Office (Suite 214) extractions

| ID | Filename | Fmt | Tier | Summary |
|---|---|---|---|---|
| P4-OFF-01 | `RIT-OFF_office_pc_extraction_report.pdf` | PDF (BANNER) | MF | Examiner summary of the office workstation image: recovered client folders, the access matrix, service records, email remnants. Findings only. |
| P4-OFF-02 | `client_access_matrix.csv` | CSV | MF | **The centerpiece.** Reston's own inventory of provisioned accesses across clients: provisioned date, technician, permissions, status (dormant/listed/SOLD), sale ref. Four victims SOLD (ref BH-0314); **SaturnV Mart LISTED, unsold**; benign clients marked normal. The four-phase lifecycle in the subject's own file. |
| P4-OFF-03 | `RIT-OFF_restonit_client_index.csv` | CSV | CO | Full RestonIT client folder index recovered from the machine — **first appearance of SaturnV Mart** among ~11 clients. |
| P4-OFF-04 | `saturnv_client_folder_notes.txt` | TXT | MF | Contents of the SaturnV Mart client folder: recent engagement, provisioned account `svc_inventory` still live and unused. The notification trigger — active, preventable exposure. |
| P4-OFF-05 | `RIT-OFF_samsmith_service_tickets.csv` | CSV | CO | Service ticket log from coworker Sam Smith's work profile: visit dates and assigned technician. The backdoor-provisioning visits are attributed to tech "AR"; Sam's own visits are unrelated. Corroborates provisioning timeline + Reston's presence; Sam is an innocent witness. |

### Sam Smith phone

| ID | Filename | Fmt | Tier | Summary |
|---|---|---|---|---|
| P4-SS-01 | `samsmith_phone_payment_export.csv` | CSV | CO | Peer-payment app export from Sam's phone: payments from Reston to Sam clustered around the provisioning visit dates (reimbursements/bonuses). Circumstantial corroboration; innocent on Sam's side. |

### Residence extractions — the BRKR_AL identity

| ID | Filename | Fmt | Tier | Summary |
|---|---|---|---|---|
| P4-RES-01 | `RIT-RES_laptop_extraction_report.pdf` | PDF (BANNER) | MF | Examiner summary of Reston's personal laptop image: recovered PGP keyring, Tor browser artifacts, cryptocurrency wallet, Black Harbor session remnants. Findings only — no attribution conclusion drawn. |
| P4-RES-02 | `RIT-RES_pgp_keyring_export.txt` | TXT | MF | Recovered PGP keyring containing a **private** key, ID 0xA1C4 7E90 2B7F 11F0, UID `brkr_al <amr.secure@protonrelay.example>` — matches the BRKR_AL public key in P3-BH-02. The forensic identity tie. |
| P4-RES-03 | `RIT-RES_browser_artifacts.csv` | CSV | MF | Recovered browser history/artifacts: Tor Browser, Black Harbor Exchange, protonrelay webmail (`amr.secure`, `d.kort92` NOT present — Reston is seller, not buyer), CoinBridge logins. |
| P4-RES-04 | `RIT-RES_wallet_export.txt` | TXT | MF | Recovered wallet descriptor/addresses including `PACT{PLACEHOLDER-w3}` (BRKR_AL seller wallet from P3). |
| P4-RES-05 | `RIT-RES_personal_financials.csv` | CSV | CO | Personal account records: spending materially exceeding legitimate MSP income; inflows from CoinBridge. FoA lifestyle-discrepancy close. |

### Entity return (held from Packet 3)

| ID | Filename | Fmt | Tier | Summary |
|---|---|---|---|---|
| P4-FIN-01 | `coinbridge_kyc_return.pdf` | PDF | MF | CoinBridge exchange subpoena return: the account receiving `PACT{PLACEHOLDER-w3}` cash-outs; KYC + withdrawals to RestonIT operating account ****7734 / A. Reston personal ****2091. Closes the proceeds trail to the subject — the return P3 deliberately withheld. |

### Orientation

| ID | Filename | Fmt | Summary |
|---|---|---|---|
| P4-CP | `00_COMMAND_POST_Day4.md` / `.pdf` | MD + PDF (BANNER) | Orients to seized/extracted evidence and the attribution phase; directs the SaturnV victim-notification follow-through (now nameable — discovered on scene); frames crypto/collaboration work and moot-court prep. |

**Total: 15 evidence files + command post set.**

---

## 4. Ceiling audit (instructor key only)
- **No file asserts the identity conclusion.** The keyring is a key; the matrix is the subject's inventory using initials "AR"; browser history is history. Students state "Reston is BRKR_AL" and support it. Verified: no file contains a sentence equating Reston with BRKR_AL or declaring guilt.
- **Examiner reports state findings, not conclusions** — recovered X, recovered Y; interpretation deferred.
- **SaturnV is live and unsold** — justifies the notification urgency; the only preventable victim.
- **Sam Smith stays innocent** — his records incriminate Reston; nothing incriminates Sam.

## 5. New IOCs (append to registry)
| IOC | Type | Role | First appears |
|---|---|---|---|
| SaturnV Mart / `svc_inventory` | Victim (5th) / live account | Preventable ongoing exposure | P4-OFF-02/03/04 |
| PGP 0xA1C4 7E90 2B7F 11F0 (private) | Key | BRKR_AL identity tie on subject device | P4-RES-02 |
| RestonIT acct ****7734 / personal ****2091 | Bank accts | Proceeds destination | P4-FIN-01, P4-RES-05 |
| "AR" (technician code) | Identity | Reston on provisioning visits | P4-OFF-02/05 |

## 6. Flaggable invented specifics
- SaturnV provisioned date (2026-06-22) and unsold status — tune to your KCR inject timing.
- Notebook page content, personal-spend figures, Sam payment amounts — fictional, adjust freely.
- Instructor answer key (course-wide) is the natural companion to this packet; recommend building it next so the moot-court panel has the canonical conclusion + element-by-element evidence map.
