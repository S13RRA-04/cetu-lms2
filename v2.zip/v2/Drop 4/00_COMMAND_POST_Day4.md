`UNCLASSIFIED//FOUO//PACT`

# COMMAND POST INSTRUCTION SET — DAY 4

_PACT — Practical Applications to Cyber Threats · Command Post Instruction Set_

- **To:** Assigned Cyber Squad
- **From:** Command Post / Case Management (SSA)
- **Re:** Attribution, proceeds, and case assembly
- **Evidence Drop:** Packet 4 — seizure returns and forensic extractions

## 1. SITUATION
Yesterday's search has been processed. Today's drop is what came off the scene: forensic extractions from the seized devices, copies of the physical items collected, and the exchange return that was outstanding. Today the squad brings the case together — attribution to a named subject, the money trail, and the charging picture — and completes the victim-notification obligation identified during the operation.

## 2. TODAY'S DROP
- **`Custody`** — the seized-evidence inventory — reconcile it against your on-scene forms
- **`Physical copies`** — evidence photo log and a scanned notebook page
- **`Office extractions`** — the subject's own access records, client index, and service records
- **`Residence extractions`** — keyring, browser artifacts, and cryptocurrency wallet from the personal laptop
- **`Financial`** — personal records and the exchange KYC return

The material is direct, and much of it is the subject's own. That does not relieve you of the work: the conclusion is yours to state and to support, artifact by artifact.

## 3. STANDING ORDERS
- Attribution is an analytic product. Reach it from the evidence, assign a confidence level, and state exactly which artifacts carry it. Keep confidence language in the intelligence product; keep the charging document to facts.
- Reconcile custody first. Confirm every item in the inventory against the on-scene forms and flag any gap before you build on that item — a defect you miss today is a defect opposing counsel finds Friday.
- VICTIM NOTIFICATION — the search identified a client with a live, unused access that has not been sold or exploited. This is a preventable harm. Treat notification of that victim as a priority action today, coordinated through the command post, not an afterthought.
- Follow the money to a person and to recoverable assets. Separate legitimate business revenue from proceeds.

## 4. SQUAD OBJECTIVES
1. An attribution assessment naming the subject, with confidence levels and the supporting artifacts.
2. A completed financial picture: proceeds traced to the subject and assets identified.
3. A charging outline mapping each element of the offense(s) to specific evidence.
4. A victim-notification action for the newly identified live-access client, coordinated with the command post.
5. A reconciled evidence inventory with any custody exceptions noted.
6. The threads you will each carry into tomorrow's moot court.

## 5. WORKSHOP FLOW
- Morning block works attribution and case assembly.
- Afternoon block works cryptocurrency tracing, asset identification, and information-sharing products.
- Role-specific taskings are issued at the start of each block.

## 6. CLOSEOUT AND HANDOFF
Everything you produce today is what you defend tomorrow. Tomorrow is the moot court and final review: your attribution assessment, your charging outline, your financial picture, and your handling of evidence and notification will be examined. Leave your lane ready to present.

## 7. DO NOT
- Do not overstate attribution; tie confidence to specific artifacts and keep hedging out of the charging document.
- Do not build on an item whose custody you have not reconciled.
- Do not deprioritize the live-victim notification.

`UNCLASSIFIED//FOUO//PACT`
