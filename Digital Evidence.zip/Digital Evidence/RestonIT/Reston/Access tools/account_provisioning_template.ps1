<#
.SYNOPSIS
    RestonIT standard client-onboarding account provisioning template.

.DESCRIPTION
    Creates a vendor/integration service account in the target client's
    Active Directory environment during an onboarding or project engagement.
    This is the same template used across RestonIT's managed-services
    client base for scoped service accounts (backup proxies, integration
    syncs, vendor gateways, etc).

    This script only performs standard, documented AD administration
    (New-ADUser / Add-ADGroupMember / Set-ADAccountExpiration). It does not
    contain any remote-access, persistence, or data-collection logic.

.NOTES
    Per the MSA data-handling clause, generated passwords must be delivered
    to the client contact out-of-band (phone or in-person) and never stored
    in this script, in tickets, or in email.
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$ClientCode,

    [Parameter(Mandatory = $true)]
    [string]$AccountName,

    [Parameter(Mandatory = $true)]
    [string]$Description,

    [Parameter(Mandatory = $true)]
    [string]$OUPath,

    [string[]]$GroupMemberships = @(),

    # Project-close deprovisioning date. Ticketing policy requires this be
    # set whenever an account is created for a time-boxed engagement.
    [datetime]$AccountExpirationDate,

    [switch]$PasswordNeverExpires,

    # When set, the account is excluded from the quarterly access-review
    # export. Reserved for accounts explicitly approved by the account
    # manager as long-lived infrastructure accounts (e.g. backup service
    # accounts). Should not be used for time-boxed project accounts.
    [switch]$ExcludeFromAccessReview
)

Import-Module ActiveDirectory

function New-ClientServiceAccount {
    param($ClientCode, $AccountName, $Description, $OUPath, $GroupMemberships, $AccountExpirationDate, $PasswordNeverExpires, $ExcludeFromAccessReview)

    $securePassword = ConvertTo-SecureString (New-Guid).Guid -AsPlainText -Force

    $newUserParams = @{
        Name                  = $AccountName
        SamAccountName        = $AccountName
        Description           = "$Description (RestonIT-managed, client: $ClientCode)"
        Path                  = $OUPath
        AccountPassword       = $securePassword
        Enabled               = $true
        ChangePasswordAtLogon = $false
        PasswordNeverExpires  = [bool]$PasswordNeverExpires
    }

    New-ADUser @newUserParams

    foreach ($group in $GroupMemberships) {
        Add-ADGroupMember -Identity $group -Members $AccountName
    }

    if ($AccountExpirationDate) {
        Set-ADAccountExpiration -Identity $AccountName -DateTime $AccountExpirationDate
    }
    else {
        Write-Warning "No AccountExpirationDate supplied. Ticketing policy requires a deprovisioning date for time-boxed project accounts."
    }

    if ($ExcludeFromAccessReview) {
        # Tag consumed by the quarterly access-review export job.
        Set-ADUser -Identity $AccountName -Replace @{ extensionAttribute7 = "EXCLUDE_ACCESS_REVIEW" }
    }

    Write-Output "Provisioned $AccountName for client $ClientCode in $OUPath."
}

New-ClientServiceAccount -ClientCode $ClientCode -AccountName $AccountName -Description $Description `
    -OUPath $OUPath -GroupMemberships $GroupMemberships -AccountExpirationDate $AccountExpirationDate `
    -PasswordNeverExpires:$PasswordNeverExpires -ExcludeFromAccessReview:$ExcludeFromAccessReview

# Example invocations kept for reference (client environments/OU paths redacted):
#
# .\account_provisioning_template.ps1 -ClientCode RMH -AccountName fac-vendor-svc17 `
#     -Description "Facilities vendor coordination - HVAC controls project" -OUPath "OU=Vendors,DC=redstone,DC=local" `
#     -GroupMemberships "Facilities-Vendor-Access" -AccountExpirationDate 2026-01-22 -PasswordNeverExpires
#
# .\account_provisioning_template.ps1 -ClientCode CYD -AccountName custsync_api02 `
#     -Description "Customer sync integration" -OUPath "OU=Integrations,DC=cyberdyne,DC=local" `
#     -GroupMemberships "Integration-Service-Accounts" -AccountExpirationDate 2025-12-14 -PasswordNeverExpires -ExcludeFromAccessReview
