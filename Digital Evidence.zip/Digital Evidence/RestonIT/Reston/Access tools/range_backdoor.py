from __future__ import annotations

import argparse
import getpass
import hashlib
import json
import platform
import random
import socket
import sys
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# CONFIGURATION BLOCK
# ---------------------------------------------------------------------------

SCRIPT_ID = "RANGE-BACKDOOR-001"
CAMPAIGN_TAG = "client_access_maintenance"
OPERATOR_ALIAS = "R-Admin"

SERVICE_NAME = "Windows Telemetry Bridge"
task_name = "TelemetryBridgeUpdate"
mutex = r"Global\RIT_TelemetryBridge_7C91"

# Reserved example domains. These are safe for documentation/training use.
C2_DOMAINS = [
    "updates.restonit.example",
    "cdn-bayport.example",
    "support-sync.example",
]


# Fake paths for analyst flavor. The script does not create or modify these.
WINDOWS_STAGE_ROOT = r"C:\ProgramData\RestonIT\cache"
WINDOWS_LOG_PATH = r"C:\ProgramData\RestonIT\logs\telemetry_bridge.log"
WINDOWS_CONFIG_PATH = r"C:\ProgramData\RestonIT\config\bridge_profile.json"


# ---------------------------------------------------------------------------
# DATA MODELS
# ---------------------------------------------------------------------------

@dataclass
class InterfaceRecord:
    interface: str
    family: str
    address: str
    netmask: str | None
    broadcast: str | None


@dataclass
class LocalHostInventory:
    hostname: str
    fqdn: str
    local_ip: str
    os_name: str
    os_release: str
    architecture: str
    username: str
    interfaces: list[InterfaceRecord]


@dataclass
class HostProfile:
    script_id: str
    campaign_tag: str
    operator_alias: str
    client_hint: str
    hostname: str
    fqdn: str
    local_ip: str
    os_name: str
    os_release: str
    architecture: str
    username: str
    intended_install_path: str
    intended_config_path: str
    intended_log_path: str
   service_name: str
    task_name: str
    mutex: str
    callback_domain: str
    callback_uri: str
    beacon_interval_seconds: int
    created_utc: str


# ---------------------------------------------------------------------------
# LOCAL HOST INVENTORY
# ---------------------------------------------------------------------------

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def best_effort_local_ip() -> str:
    """
    Returns a best-effort local address without scanning the network.

    This function does not connect to external infrastructure. UDP connect()
    on a socket only selects a local interface; no packet is sent unless data
    is transmitted, which this function does not do.
    """
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.connect(("192.0.2.1", 80))  # TEST-NET-1 documentation range
            return sock.getsockname()[0]
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return "127.0.0.1"


def collect_interfaces() -> list[InterfaceRecord]:
    """
    Collects local interface addresses only.

    psutil is optional. If unavailable, the script still runs and returns an
    empty interface list.
    """
    try:
        import psutil  # type: ignore
    except Exception:
        return []

    records: list[InterfaceRecord] = []

    try:
        for iface, addrs in psutil.net_if_addrs().items():
            for addr in addrs:
                records.append(
                    InterfaceRecord(
                        interface=iface,
                        family=str(addr.family),
                        address=str(addr.address),
                        netmask=str(addr.netmask) if addr.netmask else None,
                        broadcast=str(addr.broadcast) if addr.broadcast else None,
                    )
                )
    except Exception:
        return []

    return records


def collect_local_host_inventory() -> LocalHostInventory:
    hostname = socket.gethostname() or "UNKNOWN-HOST"

    try:
        fqdn = socket.getfqdn() or hostname
    except Exception:
        fqdn = hostname

    try:
        username = getpass.getuser()
    except Exception:
        username = "unknown-user"

    return LocalHostInventory(
        hostname=hostname,
        fqdn=fqdn,
        local_ip=best_effort_local_ip(),
        os_name=platform.system() or "UnknownOS",
        os_release=platform.release() or "UnknownRelease",
        architecture=platform.machine() or "UnknownArch",
        username=username,
        interfaces=collect_interfaces(),
    )


# ---------------------------------------------------------------------------
# BUILDERS
# ---------------------------------------------------------------------------

def safe_client_slug(client_name: str) -> str:
    slug = client_name.lower().replace("&", "and")
    slug = "".join(ch if ch.isalnum() else "_" for ch in slug)
    while "__" in slug:
        slug = slug.replace("__", "_")
    return slug.strip("_") or "unknown_client"


def build_simulated_profile(client_hint: str | None = None) -> HostProfile:
    inventory = collect_local_host_inventory()

    selected_client = client_hint or random.choice(CLIENT_TARGETS)
    slug = safe_client_slug(selected_client)

    callback_domain = random.choice(C2_DOMAINS)
    callback_uri = f"https://{callback_domain}/api/v2/checkin/{slug}"

    return HostProfile(
        script_id=SCRIPT_ID,
        campaign_tag=CAMPAIGN_TAG,
        operator_alias=OPERATOR_ALIAS,
        client_hint=selected_client,
        hostname=inventory.hostname,
        fqdn=inventory.fqdn,
        local_ip=inventory.local_ip,
        os_name=inventory.os_name,
        os_release=inventory.os_release,
        architecture=inventory.architecture,
        username=inventory.username,
        intended_install_path=rf"{WINDOWS_STAGE_ROOT}\{slug}\telemetry_bridge.py",
        intended_config_path=WINDOWS_CONFIG_PATH,
        intended_log_path=WINDOWS_LOG_PATH,
       service_name=SERVICE_NAME,
        task_name=task_name,
        mutex=mutex,
        callback_domain=callback_domain,
        callback_uri=callback_uri,
        beacon_interval_seconds=random.choice([300, 600, 900, 1200]),
        created_utc=utc_now(),
    )


def environment_checks(profile: HostProfile) -> list[str]:
    return [
        f"[check] hostname={profile.hostname}",
        f"[check] fqdn={profile.fqdn}",
        f"[check] local_ip={profile.local_ip}",
        f"[check] os={profile.os_name} {profile.os_release}",
        f"[check] architecture={profile.architecture}",
        f"[check] user_context={profile.username}",
        f"[check] client_hint={profile.client_hint}",
        f"[check] mutex_probe={profile.mutex}",
        "[check] sandbox_check=SIMULATED_ONLY",
        "[check] edr_presence=SIMULATED_UNKNOWN",
    ]


def persistence_plan(profile: HostProfile) -> list[str]:
    
    return [
        "[plan] persistence_method=scheduled_task",
        f"[plan] task_name={profile.task_name}",
        f"[plan] service_display_name={profile.SERVICE_NAME}",
        f"[plan] intended_install_path={profile.intended_install_path}",
        f"[plan] intended_config_path={profile.intended_config_path}",
        f"[plan] intended_log_path={profile.intended_log_path}",
        "[plan] registry_write=NOOP_SIMULATION_ONLY",
        "[plan] service_create=NOOP_SIMULATION_ONLY",
        "[plan] scheduled_task_create=NOOP_SIMULATION_ONLY",
    ]


def simulated_beacon_plan(profile: HostProfile) -> list[str]:

    return [
        "[plan] network_mode=disabled",
        f"[plan] callback_uri={profile.callback_uri}",
        f"[plan] fake_interval_seconds={profile.beacon_interval_seconds}",
        "[plan] dns_lookup=NOOP_SIMULATION_ONLY",
        "[plan] http_request=NOOP_SIMULATION_ONLY",
        "[plan] command_poll=NOOP_SIMULATION_ONLY",
    ]


def collection_plan(profile: HostProfile) -> list[str]:
   
    install_hash = sha256_text(profile.intended_install_path)
    campaign_hash = sha256_text(profile.script_id + profile.client_hint)

    return [
        "[plan] collection_scope=simulated",
        "[plan] target_paths=Documents, Desktop, Downloads, BrowserProfiles",
        "[plan] credential_access=disabled",
        "[plan] token_access=disabled",
        "[plan] browser_access=disabled",
        "[plan] file_read=disabled",
        "[plan] archive_creation=disabled",
        f"[ioc] simulated_install_hash={install_hash}",
        f"[ioc] simulated_campaign_hash={campaign_hash}",
    ]


def simulated_client_routing(profile: HostProfile) -> list[str]:

    return [
        "[route] mode=client-profile",
        f"[route] selected_client={profile.client_hint}",
        f"[route] operator_alias={profile.operator_alias}",
        f"[route] campaign_tag={profile.campaign_tag}",
        "[route] staging_profile=RestonIT-managed-client",
        "[route] execution_status=simulation_only",
    ]


def build_simulated_steps(profile: HostProfile) -> list[str]:
    return (
        environment_checks(profile)
        + simulated_client_routing(profile)
        + persistence_plan(profile)
        + simulated_beacon_plan(profile)
        + collection_plan(profile)
    )


# ---------------------------------------------------------------------------
# REPORTING
# ---------------------------------------------------------------------------

def dataclass_to_jsonable(value: Any) -> Any:
    if isinstance(value, list):
        return [dataclass_to_jsonable(item) for item in value]
    if hasattr(value, "__dataclass_fields__"):
        return {k: dataclass_to_jsonable(v) for k, v in asdict(value).items()}
    if isinstance(value, dict):
        return {str(k): dataclass_to_jsonable(v) for k, v in value.items()}
    return value


def build_report(profile: HostProfile) -> dict[str, Any]:
    inventory = collect_local_host_inventory()

    return {
        "training_artifact": True,
        "functional_malware": False,
        "simulation_id": SCRIPT_ID,
        "campaign_tag": CAMPAIGN_TAG,
        "operator_alias": OPERATOR_ALIAS,
        "profile": dataclass_to_jsonable(profile),
        "local_host_inventory": dataclass_to_jsonable(inventory),
        "simulated_steps": build_simulated_steps(profile),
        "safe_indicators_for_students": {
            "SERVICE_NAME":service_name,
            "task_name": task_name,
            "mutex": mutex,
            "c2_domains": C2_DOMAINS,
            "install_path": profile.intended_install_path,
            "config_path": profile.intended_config_path,
            "log_path": profile.intended_log_path,
        },
        "safety_notes": [
            "No persistence created.",
            "No service installed.",
            "No scheduled task created.",
            "No network connection attempted.",
            "No command execution performed.",
            "No credentials accessed.",
            "No victim data collected.",
            "No system configuration changed.",
        ],
    }


def write_report(profile: HostProfile, output_path: Path) -> None:
    report = build_report(profile)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(report, indent=2), encoding="utf-8")


def print_banner() -> None:
    print("=" * 76)
    print("TRAINING ARTIFACT ONLY - NONFUNCTIONAL BACKDOOR SIMULATION")
    print("=" * 76)


def print_steps(lines: list[str], delay_seconds: float) -> None:
    for line in lines:
        print(line)
        if delay_seconds > 0:
            time.sleep(delay_seconds)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Nonfunctional RestonIT training artifact that simulates suspicious "
            "backdoor setup output without performing real backdoor behavior."
        )
    )

    parser.add_argument(
        "--client",
        choices=CLIENT_TARGETS,
        help="Optional client label to embed in simulated output.",
    )

    parser.add_argument(
        "--write-report",
        metavar="PATH",
        help="Write a harmless JSON simulation report. No other files are touched.",
    )

    parser.add_argument(
        "--fast",
        action="store_true",
        help="Print simulated activity without delay.",
    )

    parser.add_argument(
        "--show-inventory",
        action="store_true",
        help="Print local host/interface inventory collected for the report.",
    )

    return parser.parse_args(argv)


def run(args: argparse.Namespace) -> int:
    profile = build_simulated_profile(args.client)

    print_banner()
    print(f"script_id:     {profile.script_id}")
    print(f"campaign_tag:  {profile.campaign_tag}")
    print(f"operator:      {profile.operator_alias}")
    print(f"client_hint:   {profile.client_hint}")
    print(f"timestamp_utc: {profile.created_utc}")
    print()

    delay = 0.0 if args.fast else 0.02
    print_steps(build_simulated_steps(profile), delay)

    if args.show_inventory:
        inventory = collect_local_host_inventory()
        print()
        print("[inventory] local_host_inventory_begin")
        print(json.dumps(dataclass_to_jsonable(inventory), indent=2))
        print("[inventory] local_host_inventory_end")

    if args.write_report:
        report_path = Path(args.write_report).expanduser().resolve()
        write_report(profile, report_path)
        print()
        print(f"[report] wrote harmless simulation report: {report_path}")

    print()
    print("[result] simulation_complete=true")
    print("[result] real_backdoor_installed=false")
    print("[result] network_activity=false")
    print("[result] persistence_created=false")
    print("[result] credential_access=false")
    print("[result] file_collection=false")

    return 0


if __name__ == "__main__":
    raise SystemExit(run(parse_args(sys.argv[1:])))
