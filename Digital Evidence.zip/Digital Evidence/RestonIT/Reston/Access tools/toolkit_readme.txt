Access Tools - working folder
personal working folder, not synced to the shared drive

Contents:

- client_access_matrix.csv
    Personal copy of the account tracker. Should match the shared drive
    version but I keep this one current more often.

- rmm_connection_profiles.csv
    Export from N-able showing last-connected dates per client. Pulled
    monthly for my own reference.

- account_provisioning_template.ps1
    Standard onboarding script, same one used for every client. Nothing
    special here, just easier to keep a local copy than dig through the
    shared scripts folder every time.

- credential_vault_export_partial.csv
    Partial export from the vault app, service accounts only. Delete this
    after cross-checking against the shared vault - shouldn't leave copies
    sitting around.

- chat_log_export.txt / bhe_negotiation_notes.txt
    Personal.

- dormant_account_checklist.txt
    Working notes, personal.
