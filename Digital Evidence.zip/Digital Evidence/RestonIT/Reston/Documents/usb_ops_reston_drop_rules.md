# Reston Drop Rules

- Never post twice from the same residential IP.
- Use carrier NAT or business ISP Wi-Fi for forum contact.
- Netlify is lure only. Pixelplay is operations.
- Keep Pinecrest language in the first message. It increases open rate.
- If asked about staff validation, use "M. Vale" and delay.

Operator note: S0cksProxy keeps forgetting this.

Evidence token: PACT{R5-RULES-MVALE-PINECREST}
