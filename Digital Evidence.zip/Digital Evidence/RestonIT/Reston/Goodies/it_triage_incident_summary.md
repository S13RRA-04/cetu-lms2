# Incident Summary - STEM-LAP-014

**Organization:** Redstone Youth STEM Foundation
**User:** emarrow (Elise Marrow)
**Host:** STEM-LAP-014
**Date:** 2026-05-08
**Status:** Contained - host isolated 15:41, awaiting forensic imaging

## Sequence of events (local time)

- 15:18 - User opens `Pinecrest_Sponsorship_Packet.zip`, received via email from "Pinecrest Community Grants" (grants@pinecrest-community.org)
- 15:19 - `powershell.exe` runs a hidden-window command retrieving content from `gamerunderground.netlify.app`
- 15:19 - `rundll32.exe` loads `C:\ProgramData\pcrest\pcrest.dat` via the `StartW` export
- 15:19 - Persistence added via `HKCU\...\Run` (`PCrestUpdate`) and a scheduled task (`PCrestMaintenance`)
- 15:20-15:40 - Periodic outbound connections to `proxy.pixelplay.run` (203.0.113.77:443), roughly every 5 minutes
- 15:24 - Ransom note `README_RESTORE_FILES.txt` written to the user's desktop; high-entropy file writes observed
- 15:34 - IT-Triage begins preserving the host (see internal chat export)
- 15:41 - Host isolated from network

## Open items for investigators

- Sender domain `pinecrest-community.org` does not match the real Pinecrest Foundation's known domain
- Grant language in the phishing attachment appears copied from the Foundation's own April grant draft (possible prior compromise of a mailbox or shared drive - scope not yet determined)
- `proxy.pixelplay.run` and `api.pixelplay.run` should be checked against other incidents in the case set
- No confirmed identity for "M. Vale" on any Pinecrest Foundation staff list
