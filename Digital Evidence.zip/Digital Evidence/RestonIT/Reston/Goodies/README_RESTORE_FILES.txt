All files on this computer have been encrypted.

To recover your files, you must purchase the decryption key.

Price: 1.15 BTC (increases after 72 hours)
Payment address: [R4-WALLET-INVENTORY]

After payment, contact [R4-CONTACT-INVENTORY] with your unique ID below.
Do not rename or attempt to decrypt files yourself.

Unique ID: STEM-LAP-014-88231

You have 72 hours.
