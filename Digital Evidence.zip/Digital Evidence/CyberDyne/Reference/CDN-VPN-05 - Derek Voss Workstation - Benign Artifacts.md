UNCLASSIFIED // FOR TRAINING USE ONLY (FOUO) // PACT

# Workstation Artifacts — Derek Voss (Benign)

**Item ID:** CDN-VPN-05
**Product Type:** System Export — Workstation Files (native evidence, consented seizure)
**Device:** Voss's CyberDyne-issued laptop
**Classification:** Benign / corroborating — no case-relevant recon, persistence, or C2 material present

---

## Email — Order Confirmation

```
From: orders@netlynx-store.test
To: dvoss.personal@webmail.test
Date: 2026-02-09
Subject: Your NetLynx order has shipped!

Hi Derek,

Your order #NL-7729341 (NetLynx VR-450 Router, Qty 1) has shipped and
should arrive within 3-5 business days. Track your package here: [link]

Thanks for choosing NetLynx!
```

## Personal Notes File (found on desktop, "notes.txt")

```
things to do
- fix ticket queue backlog before Friday
- ask marcus about the closet re-cabling project, keeps getting pushed
- router should be in by weds, gonna set it up in the closet so i can
  check the HVAC alerts from home instead of driving in every time
  something pings at 2am
- remember to actually change the admin password this time lol
- return library book
```

## Open Ticket (never formally closed)

```
Ticket: CDN-IT-4471
Opened: 2026-02-08
Opened by: Derek Voss
Category: Facilities / Network
Summary: "Personal note - setting up remote monitoring access for
  after-hours facilities alerts. Will document properly once I have
  it working the way I want."
Status: Open (no update since 2026-02-11)
Assigned: Derek Voss
```

## Browser History (relevant excerpt)

```
2026-02-08  netlynx-store.test/products/vr-450
2026-02-09  netlynx-store.test/orders/NL-7729341
2026-02-11  netlynx-support.test/setup-guide/vr-450
2026-02-11  whatismyip.test
```

## Note

Nothing recovered from Voss's workstation shows awareness of, or involvement in, use of the device by any party other than himself. The unclosed ticket and casual personal note both predate and corroborate his interview statement (CDN-VPN-04) without prompting.

UNCLASSIFIED // FOR TRAINING USE ONLY (FOUO) // PACT
