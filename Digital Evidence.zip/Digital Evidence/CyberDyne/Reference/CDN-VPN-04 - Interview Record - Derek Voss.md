UNCLASSIFIED // FOR TRAINING USE ONLY (FOUO) // PACT

# Interview Record — Derek Voss

**Item ID:** CDN-VPN-04
**Product Type:** FD-302 (fictional/training format)
**Interviewee:** Derek Voss
**Role:** Network Operations Technician, CyberDyne Data Center (reports to Marcus Iyer)
**Date:** [D+XX]
**Location:** CyberDyne Data Center, Main Facility

---

On [date], Derek Voss was interviewed by [FIELD AGENT] at CyberDyne Data Center. Voss was advised of the identity of the interviewing agent and the nature of the interview. Voss provided the following information voluntarily.

Voss stated he has worked as a Network Operations Technician at CyberDyne for approximately two years, primarily covering night and weekend facilities-network support. Voss stated that CyberDyne's formal remote-access process — which requires a documented request and approval from Marcus Iyer or the IT security team — was, in his words, "slow and annoying" for the kind of quick, after-hours checks he sometimes needed to do from home.

Voss stated that in approximately mid-February 2026, he purchased a consumer-grade VPN router (identified to the interviewing agent as the device recovered and described in CDN-VPN-01) using his own funds, and installed it himself in the facilities network closet, connecting it to an unused switch port. Voss stated he did not document this installation, did not inform Marcus Iyer or any other CyberDyne employee, and did not request authorization before or after installing it. Voss stated his intent was solely to allow himself faster remote access to facilities-network monitoring tools during off-hours.

Voss stated he configured the device using its default administrative settings because he "didn't think about it" and intended to change the password later. Voss stated he never did so.

When shown the session log excerpt in CDN-VPN-02, Voss stated he did not recognize the source IP address 203.0.113.77 and had no knowledge of any RestonIT personnel accessing the device. Voss stated he was not aware the device was reachable from outside CyberDyne's network at all, and appeared surprised and concerned when the interviewing agent explained that the device's admin interface was exposed to the public internet.

When shown the unrelated session excerpt in CDN-VPN-03, Voss stated he had no explanation for the additional sessions and reiterated that he was the only person he believed had access to the device.

Voss stated he received no payment, benefit, or compensation from any party in connection with the device, and denied any knowledge of, or involvement in, unauthorized access to any CyberDyne customer systems or any of CyberDyne's clients' networks. Voss was cooperative throughout the interview and consented to the seizure of his personal workstation (see CDN-VPN-05) for forensic review.

Voss stated he understood the device would need to be removed and that he was willing to answer further questions if needed.

*[End of interview.]*

---

*Training note: This interview is designed to model a cooperative, non-culpable witness whose negligence created an opportunity later exploited by others. It should not be treated by students as exculpatory in a way that closes the thread — it should instead redirect attention to the device's logs and to RestonIT's connection to them.*

UNCLASSIFIED // FOR TRAINING USE ONLY (FOUO) // PACT
