UNCLASSIFIED // FOR TRAINING USE ONLY (FOUO) // PACT

# Device Export — Facilities Closet VPN Appliance

**Item ID:** CDN-VPN-01
**Product Type:** System Export — Network Device Configuration
**Location Recovered:** CyberDyne Data Center, Main Facility — Facilities Network Closet (adjacent to primary switch rack)
**Collected By:** [FIELD EXAMINER — CyberDyne Consent Search, Visit 2]
**Collection Date:** [D+XX — post–Drop 3 revisit]
**Consent Basis:** Voluntary consent to search, CyberDyne Data Center (see CDN-VPN-00 — Consent to Search form)

---

## Device Summary

| Field | Value |
|---|---|
| Make / Model | NetLynx VR-450 (consumer-grade VPN/router) |
| Serial Number | NL450-88213-CDN |
| Facilities Network Port | Closet switch, port 14 (unlabeled, undocumented in CyberDyne's port map) |
| WAN-Facing Address | 192.0.2.80 |
| LAN-Side Address (Facilities VLAN) | 10.60.5.14 |
| Admin Interface Credentials | admin / admin (factory default — never changed) |
| UPnP | Enabled |
| Remote Admin Access | Enabled (WAN-facing) |
| Firmware Version | 2.1.6 (released 2023 — no updates applied) |
| Configured VPN Protocol | PPTP (legacy, weak encryption) |

## Circumstances of Discovery

This device does not appear on CyberDyne's facilities network asset inventory or in any RestonIT-issued support ticket. It was located during a consented technical walk-through of the facilities closet, prompted by CyberDyne's client relationship with RestonIT LLC surfacing during document review (see Drop 4 — RestonIT Client Matrix). The device was physically connected to an unused switch port and drawing power from a shared outlet strip also serving documented facilities equipment (see CDN-VPN-06 — HVAC Controller Export, benign).

The device's WAN-facing administrative interface and default credentials mean it was reachable — and configurable — by anyone on the public internet who located it via routine scanning. CyberDyne's own perimeter firewall (see CDN-VPN-07 — Perimeter Firewall Config, benign) does not restrict inbound access to the facilities VLAN's secondary WAN handoff, which this device was plugged into.

## Configuration Export (Relevant Excerpt)

```
SYSTEM: NetLynx VR-450
FIRMWARE: 2.1.6
WAN_IP: 192.0.2.80
LAN_IP: 10.60.5.14/24
DHCP: disabled
VPN_MODE: PPTP_SERVER
VPN_USERS: 1 configured
  - username: dvoss_remote
    created: 2026-02-11
    last_modified: 2026-02-11
ADMIN_ACCESS: WAN + LAN
ADMIN_USER: admin (default)
UPNP: enabled
PORT_FORWARDS:
  - WAN 1723/tcp -> LAN 10.60.5.14:1723 (PPTP)
  - WAN 47/gre -> LAN 10.60.5.14 (GRE passthrough)
```

## Note for Evidence Handling

This device is the physical anchor for the connection logs in CDN-VPN-02 (relevant session activity) and CDN-VPN-03 (unrelated traffic). Both logs were extracted from this appliance's onboard session history, which retains approximately 150 days of connection records at default logging settings.

UNCLASSIFIED // FOR TRAINING USE ONLY (FOUO) // PACT
