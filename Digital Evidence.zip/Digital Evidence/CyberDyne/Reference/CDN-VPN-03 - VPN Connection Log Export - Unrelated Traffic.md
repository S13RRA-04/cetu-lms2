UNCLASSIFIED // FOR TRAINING USE ONLY (FOUO) // PACT

# VPN Connection Log Export — Unrelated Traffic Excerpt

**Item ID:** CDN-VPN-03
**Product Type:** System Export — VPN Session Log (native export, onboard appliance storage)
**Source Device:** CDN-VPN-01 (NetLynx VR-450, facilities closet)
**Log Window Covered:** 2026-01-25 through [collection date]

---

## Investigative Note

The `dvoss_remote` account's factory-default credentials and WAN-exposed admin interface (see CDN-VPN-01) made this device broadly discoverable to routine internet scanning, not solely to RestonIT. The sessions below are drawn from the same onboard log as CDN-VPN-02 but originate from a wide range of unrelated source IPs, with no consistent client fingerprint, no consistent timing pattern, and no correlation to any of the four affected victim organizations' account activity or reported intrusion dates.

This traffic is provided so investigators can distinguish signal (CDN-VPN-02) from noise. Multiple unrelated actors appear to have independently found and used this same exposed device for their own purposes, unconnected to this case.

## Log Excerpt (Representative Sample)

```
SESSION_LOG — CDN-VPN-01 — dvoss_remote account (unrelated sessions)
--------------------------------------------------------------
2026-02-19 04:12:55  connect    src=198.51.100.150 client=OpenVPN-generic/2.4
2026-02-19 04:15:01  disconnect duration=00:02:06
2026-02-27 11:47:33  connect    src=203.0.113.201  client=custom-tunnel/unk
2026-02-27 13:02:19  disconnect duration=01:14:46
2026-03-03 02:20:08  connect    src=192.0.2.199    client=OpenVPN-generic/2.4
2026-03-03 02:26:51  disconnect duration=00:06:43
2026-03-09 19:55:14  connect    src=198.51.100.203 client=custom-tunnel/unk
2026-03-09 20:41:02  disconnect duration=00:45:48
2026-04-02 03:11:07  connect    src=203.0.113.55   client=OpenVPN-generic/2.4
2026-04-02 03:14:22  disconnect duration=00:03:15
2026-04-19 08:02:44  connect    src=192.0.2.211    client=custom-tunnel/unk
2026-04-19 08:57:30  disconnect duration=00:54:46
2026-05-06 22:14:09  connect    src=198.51.100.87  client=OpenVPN-generic/2.4
2026-05-06 22:19:55  disconnect duration=00:05:46
--------------------------------------------------------------
```

## Analytical Note (Instructor Reference Only)

*Do not distribute this section to students; the log excerpt above is the student-facing portion of this document.*

These sessions represent commodity abuse of an exposed, default-credential consumer VPN — a common real-world pattern where poorly secured home/small-business network gear is discovered via mass internet scanning and used as disposable relay infrastructure by unrelated criminal actors. None of these source IPs, client fingerprints, or timing windows correlate to RestonIT, to Reston personally, or to any of the four victim intrusions. Students who flag every session in CDN-VPN-02 and CDN-VPN-03 as equally significant, rather than isolating the consistent pattern in CDN-VPN-02, have missed the point of this inject. Students who dismiss CDN-VPN-02 as "probably also unrelated noise" because the device was clearly exposed to everyone have also missed it — the fingerprint/timing/destination consistency is what separates signal from noise here, not the fact that the device was exposed.

UNCLASSIFIED // FOR TRAINING USE ONLY (FOUO) // PACT
