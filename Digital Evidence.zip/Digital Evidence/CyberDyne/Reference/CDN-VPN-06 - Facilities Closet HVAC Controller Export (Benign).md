UNCLASSIFIED // FOR TRAINING USE ONLY (FOUO) // PACT

# Device Export — Facilities Closet HVAC Controller (Benign)

**Item ID:** CDN-VPN-06
**Product Type:** System Export — Network Device Configuration
**Location Recovered:** CyberDyne Data Center, Main Facility — Facilities Network Closet (same closet as CDN-VPN-01)
**Classification:** Benign — documented CyberDyne asset, no case relevance

---

## Device Summary

| Field | Value |
|---|---|
| Make / Model | ClimateSense CS-200 Building Controller |
| Facilities Network Port | Closet switch, port 6 (documented) |
| LAN-Side Address | 10.60.5.9 |
| Asset Tag | CDN-FAC-0087 (present in CyberDyne asset inventory) |
| Function | HVAC scheduling and alert thresholds for facilities zone |

## Note

This device is fully documented in CyberDyne's facilities asset inventory, has no WAN-facing interface, and its logs show only routine temperature/humidity alert history consistent with normal building operations. Included in this evidence set to prevent the facilities closet search from being a single-item exercise — students should confirm this device's benign status rather than assume it based on its presence near CDN-VPN-01.

UNCLASSIFIED // FOR TRAINING USE ONLY (FOUO) // PACT
