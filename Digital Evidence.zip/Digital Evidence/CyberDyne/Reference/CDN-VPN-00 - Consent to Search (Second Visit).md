UNCLASSIFIED // FOR TRAINING USE ONLY (FOUO) // PACT

# Consent to Search — CyberDyne Data Center (Second Visit)

**Item ID:** CDN-VPN-00
**Product Type:** FBI Form — Consent to Search (fictional/training format)
**Applies to:** CyberDyne Data Center, Main Facility, 4100 Explorer Boulevard, Huntsville, AL 35806
**Basis:** Voluntary consent — no warrant sought or required for this visit

---

## 1. Authorization

I, **Marcus Iyer**, in my capacity as Facilities & IT Coordinator for CyberDyne Data Center, and as an individual with actual authority over the physical facilities network closet and its contents, hereby authorize agents of the Federal Bureau of Investigation to conduct a technical examination of:

- The facilities network closet and all network infrastructure contained within it
- Any device connected to the facilities network segment (VLAN 60) not previously disclosed in CyberDyne's asset inventory
- Configuration and log data from any such device, for the purpose of the ongoing investigation into unauthorized network activity affecting CyberDyne Data Center

## 2. Scope Note

This is a **second, expanded consent** beyond the initial Day 1 walkthrough (see Drop 1 — CyberDyne Initial Incident Timeline and Account Metadata). The initial visit was scoped to customer-portal integration account activity. This visit is scoped to the physical facilities network closet, prompted by CyberDyne's business relationship with RestonIT LLC surfacing as a common thread across multiple affected organizations (see Drop 4 — RestonIT Client Matrix).

## 3. Rights Acknowledged

I have been advised that:
- I have the right to refuse this search
- Any evidence found may be used in a criminal proceeding
- I may withdraw this consent at any time before the search is complete

## 4. Signatures

**Consenting Individual:** Marcus Iyer
**Title:** Facilities & IT Coordinator, CyberDyne Data Center
**Date:** [D+XX]

**Witnessing Agent:** [FIELD AGENT NAME]
**Field Office:** [FIELD OFFICE]

---

*Training note: This form documents that CyberDyne — as the network owner — consented to expanded examination once its RestonIT relationship became relevant. No warrant was sought because CyberDyne, not a suspect, controls the premises. Contrast with the Drop 6 search warrants required at RestonIT's office and Reston's residence, where the subjects do not consent.*

UNCLASSIFIED // FOR TRAINING USE ONLY (FOUO) // PACT
