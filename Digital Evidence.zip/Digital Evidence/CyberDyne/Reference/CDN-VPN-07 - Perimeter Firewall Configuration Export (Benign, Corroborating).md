UNCLASSIFIED // FOR TRAINING USE ONLY (FOUO) // PACT

# Device Export — Perimeter Firewall Configuration (Excerpt)

**Item ID:** CDN-VPN-07
**Product Type:** System Export — Network Device Configuration
**Location Recovered:** CyberDyne Data Center, Main Facility — Server Closet (primary firewall, distinct from facilities closet)
**Classification:** Benign / weakly corroborating — documented CyberDyne asset, explains reachability of CDN-VPN-01

---

## Device Summary

| Field | Value |
|---|---|
| Make / Model | CyberDyne primary perimeter firewall (documented asset) |
| Relevant Interface | Secondary WAN handoff, facilities VLAN (VLAN 60) |
| Asset Tag | CDN-NET-0002 (present in CyberDyne asset inventory) |

## Configuration Excerpt (Relevant Rule)

```
INTERFACE: WAN2 (facilities VLAN handoff)
RULE_SET: legacy-facilities-passthrough
  - allow: any -> VLAN60 (unrestricted)
  - last_modified: 2019-08-14
  - modified_by: [former employee, no longer with CyberDyne]
  - review_status: not reviewed since creation
```

## Note

This rule predates Voss's employment and predates the RestonIT relationship entirely. It was created in 2019 for a since-decommissioned facilities vendor integration and never removed. It is the reason CDN-VPN-01 was reachable from the public internet at all — the facilities VLAN's secondary WAN handoff has no inbound restriction. This is a documented, if neglected, CyberDyne configuration, not evidence of any individual's wrongdoing. Included to give students the full "why was this reachable" picture rather than treating exposure as inexplicable.

UNCLASSIFIED // FOR TRAINING USE ONLY (FOUO) // PACT
