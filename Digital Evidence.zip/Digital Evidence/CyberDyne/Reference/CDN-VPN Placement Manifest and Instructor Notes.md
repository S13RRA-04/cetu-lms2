UNCLASSIFIED // FOR TRAINING USE ONLY (FOUO) // PACT

# CyberDyne VPN Inject — Placement Manifest & Instructor Notes

**Product Type:** Range Placement Manifest — Instructor/Build Team Only
**Applies to:** Drop 4, CyberDyne Data Center, second consent-search visit (Kinetic Cyber Range)

> **INSTRUCTOR / BUILD TEAM ONLY — DO NOT DISTRIBUTE TO STUDENTS.**

---

## 1. Narrative Summary

A CyberDyne Network Operations Technician, **Derek Voss**, installed an unauthorized, default-credential VPN router in the facilities network closet in February 2026 for his own after-hours convenience. He did not know it was internet-reachable. Between March 14–24, 2026 — shortly before the Black Harbor Exchange listings referenced in Drop 5 — an IP registered to **RestonIT LLC** connected to this device repeatedly, in a pattern distinct from a much larger volume of unrelated commodity C2 traffic from other actors who separately discovered the same exposed device.

This gives students a second, independent evidentiary thread tying RestonIT to CyberDyne beyond the account-provisioning trail (Drop 3), while also teaching signal-vs-noise discrimination on shared/abused infrastructure. It does **not** by itself establish what RestonIT's connections were used for — that requires the legal process referenced in Drop 5.

Voss is a clean negligent-witness character: cooperative, no motive, no financial gain, cannot identify who else used the device. He should not be treated as a suspect by facilitators, though well-prepared students may reasonably ask more probing questions before ruling him out.

## 2. Trigger and Placement

- **Trigger:** Students pulling the Drop 4 RestonIT Client Matrix and noticing CyberDyne's "facilities network closet coordination" scope-of-support line should prompt a request for expanded access to CyberDyne beyond the Drop 1 scope.
- **Physical placement (Kinetic Cyber Range):** Facilities network closet, adjacent to the primary switch rack — same physical zone as the documented HVAC controller (CDN-VPN-06) and near, but not part of, the primary server closet where the perimeter firewall (CDN-VPN-07) lives.
- **Consent basis:** CDN-VPN-00, signed by Marcus Iyer. No warrant.

## 3. Full Item List and Tiering

| ID | Item | Tier | Notes |
|---|---|---|---|
| CDN-VPN-00 | Consent to Search (2nd visit) | Procedural | Signed by Marcus Iyer |
| CDN-VPN-01 | VPN appliance device export | Must-Find | Physical anchor for the discovery |
| CDN-VPN-02 | VPN log — RestonIT-linked sessions | Must-Find | The signal |
| CDN-VPN-03 | VPN log — unrelated traffic | Corroborating | The noise; teaches discrimination |
| CDN-VPN-04 | Voss interview (FD-302) | Corroborating | Establishes negligence, not complicity |
| CDN-VPN-05 | Voss workstation (benign) | Benign | Corroborates his account passively |
| CDN-VPN-06 | HVAC controller (benign) | Decoy | Same closet, unrelated |
| CDN-VPN-07 | Perimeter firewall config (benign) | Decoy/weak corroborating | Explains *why* the device was reachable at all |

## 4. Values Flagged for Your Review

I generated the following values without an existing vault reference — please confirm or replace before finalizing:

- **IPs used:** 192.0.2.80 (VPN WAN), 10.60.5.14 / 10.60.5.9 (facilities VLAN internal), 203.0.113.77 (RestonIT-linked source), plus six unrelated noise IPs across your existing 192.0.2.0/24, 198.51.100.0/24, and 203.0.113.0/24 documentation ranges. None collide with the four established victim intrusion IPs (203.0.113.44, 198.51.100.91, 192.0.2.44, 198.51.100.61).
- **Dates:** device installed 2026-02-11; RestonIT-linked sessions 2026-03-14 through 2026-03-24 (chosen to fall just before the Drop 5 Black Harbor Exchange listing window of 2026-03-26–2026-04-06, positioning this as Reston's pre-sale access verification — confirm this fits your Drop 5 timeline before locking it in).
- **Flag token:** left as placeholder `[FLAG: CDN-VPN-DISCOVERY]` in no file currently (I did not embed a flag anywhere, since none of these documents are structured as a CTF submission point in the way I understood your flag system to work — let me know if you want one embedded, and where, along with the actual token).
- **Fictional vendor names:** "NetLynx" (VPN router) and "ClimateSense" (HVAC controller) are invented for this set — flag if either collides with an existing vendor name elsewhere in the vault.

## 5. Not Yet Done

- No PDF rendering — these are markdown source files only, matching your normalization pipeline's expected input format
- No integration into the Drop 4 folder structure or cross-references from other Drop 4 documents (e.g., I have not edited the RestonIT Client Matrix to make the trigger more explicit — let me know if you want that)
- No answer-key entry added to the Master Insider Access Timeline

UNCLASSIFIED // FOR TRAINING USE ONLY (FOUO) // PACT
