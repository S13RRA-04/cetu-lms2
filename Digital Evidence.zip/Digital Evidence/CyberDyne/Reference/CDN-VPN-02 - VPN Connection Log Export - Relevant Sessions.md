UNCLASSIFIED // FOR TRAINING USE ONLY (FOUO) // PACT

# VPN Connection Log Export — Relevant Session Activity

**Item ID:** CDN-VPN-02
**Product Type:** System Export — VPN Session Log (native export, onboard appliance storage)
**Source Device:** CDN-VPN-01 (NetLynx VR-450, facilities closet)
**Extraction Method:** Onboard session log, read-only export, no modification to device state
**Log Window Covered:** 2026-01-25 through [collection date]

---

## Investigative Note (Factual — What the Log Shows)

The appliance's onboard PPTP session log records every connection to the `dvoss_remote` VPN account since the device was configured. The overwhelming majority of sessions are short, irregular, and originate from a wide range of IP addresses with no consistent pattern (see CDN-VPN-03 — Unrelated Traffic Excerpt).

A distinct subset of sessions — flagged below — share a single consistent source IP address, a consistent client fingerprint, and a tight two-week window immediately preceding a documented change in CyberDyne's account activity. This IP address resolves, per a basic WHOIS lookup performed during triage, to a business-class ISP allocation registered to **RestonIT LLC**, the same organization identified in Drop 3 account-creation records as the common provisioning entity across all four affected victim organizations.

No determination is made in this document as to who at RestonIT initiated these sessions, why, or what was done during them once connected onward from the facilities VLAN. That determination is outside the scope of this export.

## Log Excerpt (Flagged Sessions)

```
SESSION_LOG — CDN-VPN-01 — dvoss_remote account
--------------------------------------------------------------
2026-03-14 23:41:02  connect    src=203.0.113.77  client=WinVPN/legacy-pptp
2026-03-14 23:58:47  disconnect duration=00:17:45
2026-03-16 00:12:19  connect    src=203.0.113.77  client=WinVPN/legacy-pptp
2026-03-16 00:34:03  disconnect duration=00:21:44
2026-03-18 23:50:11  connect    src=203.0.113.77  client=WinVPN/legacy-pptp
2026-03-18 23:59:58  disconnect duration=00:09:47
2026-03-21 00:05:44  connect    src=203.0.113.77  client=WinVPN/legacy-pptp
2026-03-21 00:41:12  disconnect duration=00:35:28
2026-03-24 23:37:29  connect    src=203.0.113.77  client=WinVPN/legacy-pptp
2026-03-24 23:52:06  disconnect duration=00:14:37
--------------------------------------------------------------
WHOIS (203.0.113.77): allocation registered to RestonIT LLC,
  Huntsville, AL — business-class static IP, ISP: [fictional regional ISP]
```

## Pattern Notes (Observational Only)

- All five flagged sessions occur late evening/after hours (23:00–00:45 local)
- All five share the identical source IP and identical outdated VPN client fingerprint — consistent with the same device connecting each time, not five different people
- The window (March 14–24, 2026) falls immediately before the earliest dark-web listing activity referenced in later investigative products (see Drop 5 materials — not available at this stage of the investigation)
- No session in this flagged set shows any onward connection log from this appliance's limited logging — the device does not log destination traffic past its own WAN/LAN boundary, only VPN session connect/disconnect events. Establishing what these sessions were used for requires additional legal process (see Drop 5 — Records Request Planning)

UNCLASSIFIED // FOR TRAINING USE ONLY (FOUO) // PACT
