UNCLASSIFIED // FOR TRAINING USE ONLY (FOUO) // PACT

# Forensic Examination Report — Exhibit CDN-VPN-01

**Item ID:** CDN-VPN-12
**Product Type:** Forensic Examination Report (CART-style)
**Case Reference:** [CASE NUMBER] — CyberDyne Data Center / RestonIT LLC Matter
**Exhibit Examined:** CDN-VPN-01 (NetLynx VR-450, Serial NL450-88213-CDN)
**Examiner:** [FORENSIC EXAMINER NAME], Computer Analysis Response Team
**Examination Date(s):** 2026-04-29 through 2026-05-01
**Evidence Source:** Consented seizure, CyberDyne Data Center facilities closet (see CDN-VPN-00 — Consent to Search)

---

## 1. Exhibit Description

| Field | Value |
|---|---|
| Exhibit ID | CDN-VPN-01 |
| Device | NetLynx VR-450 consumer VPN router/appliance |
| Serial Number | NL450-88213-CDN |
| Condition at Seizure | Powered on, active VPN session in progress |
| Seizure Method | Device left powered and transported per live-seizure protocol for volatile-memory preservation; network cable disconnected from CyberDyne infrastructure prior to transport to prevent further remote access during transit |
| Seizing Agent | [FIELD AGENT NAME] |
| Seizure Location | CyberDyne Data Center, Main Facility, Facilities Network Closet |
| Seizure Date/Time | 2026-04-28 23:58 through 2026-04-29 00:14 (local) |

## 2. Chain of Custody Summary

| Date/Time | Action | Custodian |
|---|---|---|
| 2026-04-28 23:58 | Seized, live, from facilities closet | [FIELD AGENT] |
| 2026-04-29 00:14 | Volatile state captured (see 3.1); device powered down | [FIELD AGENT] |
| 2026-04-29 00:20 | Transported to field office, sealed in evidence bag #EB-4471 | [FIELD AGENT] |
| 2026-04-29 08:15 | Received by CART for forensic examination | [EXAMINER] |
| 2026-05-01 16:40 | Examination complete; exhibit returned to evidence control | [EXAMINER] |

Full chain of custody documentation, including transport logs and evidence bag seal verification, is maintained separately per standard evidence-handling procedure and is not duplicated in this report.

## 3. Methodology

### 3.1 Volatile State Preservation

Given the device was seized with an active session in progress, the seizing agent captured the live connection-tracking (NAT) table and ARP cache prior to power-down, consistent with standard practice for network-attached devices where in-memory state would otherwise be lost. This capture is preserved as a separate exhibit item (CDN-VPN-08) and is treated as a distinct, non-repeatable data source — it cannot be regenerated from the device's persistent storage.

### 3.2 Persistent Storage Imaging

Following volatile capture, the device was powered down and its onboard flash storage imaged using a hardware write-blocker to prevent any modification to the source media. A forensic image was created and verified against the source device by hash comparison before any analysis was performed on the working copy. All findings below were derived from the verified working copy; the original device and source image remain unaltered.

### 3.3 Hash Verification

| File | Algorithm | Hash |
|---|---|---|
| Full device image (raw) | SHA-256 | 4e9a1c7f2b8d3e6a5f0c9b1d8e7a6c3f2b1a0d9e8c7b6a5f4e3d2c1b0a9f8e7d |
| CDN-VPN-01 config export (extracted) | SHA-256 | 8b2f6e1a4c9d7b3e5f0a2c8d6b4e1f9a7c5b3d1e0f8a6c4b2d0e9f7a5c3b1d0e |
| CDN-VPN-02 session log (extracted) | SHA-256 | 1c4d7a0f3b6e9c2f5a8d1b4e7c0f3a6d9b2e5c8f1a4d7b0e3c6f9a2d5b8e1c4f |

Hash values for CDN-VPN-08 (live capture) are not applicable in the same sense, as that file was generated at the point of collection from volatile memory rather than extracted from static storage; its provenance is instead documented through the chain of custody in Section 2.

## 4. Findings

### 4.1 Device Configuration (from CDN-VPN-01)

Examination of the extracted configuration confirms the device was operating with factory-default administrative credentials, a WAN-facing administrative interface, UPnP enabled, and PPTP VPN service configured for a single user account (`dvoss_remote`), created 2026-02-11. No configuration change history is retained by this device beyond the current active configuration; whether settings were altered from an initial, more restrictive state could not be determined from available data.

### 4.2 Session History (from CDN-VPN-02)

Persistent session logging on the device confirmed the connection pattern previously identified: a small number of sessions from a single, consistent source IP (203.0.113.77) and client fingerprint, occurring during a discrete window (2026-03-14 through 2026-03-24), interspersed among a larger volume of sessions from unrelated, varied source IPs and client types spanning the device's full 150-day retention window. This examination independently confirms the pattern reported at time of collection; no additional sessions beyond those already reported were recovered from persistent storage, and log retention limits mean sessions predating approximately 2026-02-11 through the device's activation would not be recoverable regardless of whether they occurred.

### 4.3 Volatile Capture (from CDN-VPN-08)

The live capture obtained at seizure shows an active session at time of collection, source IP 203.0.113.77, with connection-tracking entries indicating traffic forwarded through the tunnel to destination 203.0.113.220 on ports 443/tcp and 53/udp. This is the only data source in this examination that reflects post-tunnel destination activity; the device's persistent logging does not retain this information for any other session, including the five sessions identified in Section 4.2.

### 4.4 Limitations

- This device's persistent logging captures connection metadata only (source IP, timestamp, duration, client fingerprint) and does not log destination traffic. Section 4.3's destination data is available for exactly one session — the one in progress at seizure — and cannot be extended retroactively to the other five sessions in Section 4.2.
- The device's weak, legacy PPTP encryption (MPPE-40) is a known-weak cipher; however, no payload/content data was recovered from either the persistent image or the volatile capture, as neither preserves session content, only metadata.
- The identity and ownership of 203.0.113.220 could not be determined through examination of this exhibit alone and would require additional legal process directed at the relevant network infrastructure.
- This examination cannot determine who was physically operating the connecting device at source IP 203.0.113.77 during any given session; it establishes only that the sessions originated from that address using a consistent client.

## 5. Examiner's Conclusion

The forensic examination of Exhibit CDN-VPN-01 corroborates the findings reported at time of collection (CDN-VPN-01, -02, -08) without material discrepancy. This examination did not recover any additional evidence beyond what was already identified in the field, and identifies clear boundaries on what this exhibit can and cannot establish — most notably, that destination-level evidence exists for only one of six identified sessions from source IP 203.0.113.77, and that attribution of that source IP to a specific individual is outside the scope of this exhibit examination.

*[End of report.]*

---

*Training note: This report is intentionally conservative — it neither overstates what the device evidence proves nor introduces new findings beyond what students already have access to in CDN-VPN-01/02/08. Its pedagogical purpose is to model how a forensic report properly scopes its conclusions and explicitly identifies what further legal process (subpoena/warrant for 203.0.113.220 and for records tied to 203.0.113.77) is still required — reinforcing that this device alone does not complete the case.*

UNCLASSIFIED // FOR TRAINING USE ONLY (FOUO) // PACT
