# Reston Residence & RV Workshop - Digital Evidence Placement Manifest (Draft)

Prefix convention: `RIT-RES-##` (main residence), `RIT-RV-##` (backyard RV workshop).
Cross-check both against the existing Drop 6 Search Warrant Range Build and Staging Guide
before finalizing item numbers - this draft assumes RIT-RV is a new sub-location, not yet
reserved elsewhere.

Classification legend:
- **Benign** - realistic noise, no case relevance. Needed so the range isn't a scavenger hunt
  where every item found is meaningful.
- **Signal** - directly or circumstantially probative.
- **Mixed** - split-use device/account; contains both innocuous and probative material,
  requiring the student to separate ownership/attribution before drawing conclusions.

## Main Residence

| ID | Item | Owner | Class | Contents (summary) |
|---|---|---|---|---|
| RIT-RES-01 | Shared family desktop (home office nook) | Shared | Mixed | Jordan's email/browsing, shared photo library, one saved banking bookmark, browser-saved RestonIT webmail login |
| RIT-RES-02 | Jordan's personal laptop | Jordan | Benign | Personal email, hobby/freelance files, calendar - clean baseline establishing no knowledge of the scheme |
| RIT-RES-03 | Jordan's phone backup | Jordan | Mixed | Texts with Alex (mostly innocuous; one thread noticing his late nights/odd mood), photos, contacts |
| RIT-RES-04 | Home Wi-Fi router / DHCP client list | Shared infrastructure | Signal | Device inventory showing a workshop-associated device connecting only at odd/late hours |
| RIT-RES-05 | Smart doorbell/camera event log | Shared | Signal (corroborating) | Motion/entry events, especially backyard-workshop trips late at night, correlated to known dates |
| RIT-RES-06 | Alex's personal phone backup | Alex | Mixed | Personal texts to Jordan, an encrypted-messaging app's presence (install record only, no message content - avoids duplicating Access Tools chat log), vaguely labeled calendar entries |
| RIT-RES-07 | Home printer print-job history | Shared | Benign | Routine household printing - baseline noise |
| RIT-RES-08 | Cloud photo library export | Shared | Benign | Family photos with EXIF/location data - normal home life baseline |
| RIT-RES-09 | Alex's home office desktop — **BUILT** | Alex | Signal (low-opsec) | Casual/careless activity done from home: browser history reaching the Black Harbor Exchange login page (no deep negotiation content), a locally-cached working copy of an account tracker, an unsent draft message, sloppy habits (saved passwords, no separate hotspot) - contrasts with the RV's deliberate tradecraft |

**Standing rule:** every item in this manifest must be deliverable as an actual digital file
(csv/txt/json/html/eml/pdf/etc.) - the kind of thing that could sit directly on a device's
filesystem or come out of a forensic extraction. Nothing should describe a physical object
(handwritten notes, printed photos, sticky notes) that would need to be created and staged
by hand outside this pipeline.

**Design principle for content generation:** the home office (RIT-RES-09) represents Alex's *casual* malicious activity - things he does without much discipline, on his normal home network, leaving ordinary traces (browser history, autofill, cache). The RV workshop (RIT-RV-*) represents his *serious* operational activity - deliberately isolated from the home/RestonIT networks, with real tradecraft (dedicated hotspot, offline notes, external drive backups). The RV items should read as meaningfully more careful and more damning than the home office item.

## Backyard RV Workshop — BUILT

| ID | Item | Owner | Class | Contents (summary) |
|---|---|---|---|---|
| RIT-RV-01 | RV workshop laptop | Alex | Signal (high value) | Personal/offline copies of planning notes, financial notes; kept off the home and RestonIT networks |
| RIT-RV-02 | Mobile hotspot / travel router | Alex | Signal | Connection logs showing an ISP distinct from home and RestonIT - supports "never log in from RestonIT IPs" |
| RIT-RV-03 | External USB drive | Alex | Signal | Backup copies of vault/credential exports; a password-protected container (metadata only, no working encryption content) |
| RIT-RV-04 | Notes app local cache (synced from phone, recovered from workshop laptop app data) — **BUILT** | Alex | Signal | Digital notes: dormant-account status shorthand, a redacted wallet-phrase fragment placeholder, and a rough draft of the ops rules later formalized into usb_ops_reston_drop_rules.md |
| RIT-RV-05 | Decommissioned old work laptop | Alex | Mixed | Stale RestonIT client remnants, no current activity - contrast/baseline item |

---

**Before I build actual file content, a couple of things worth confirming:**
